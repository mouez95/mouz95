# Promosport MB 3D — AI Studio Project

هذه نسخة المشروع الكاملة القابلة للتحرير. تحتوي على مصدر التطبيق، واجهة React/Vite، بيانات التطبيق، PWA، Capacitor Android، وملفات البناء.

## التشغيل بعد فتح المشروع

```bash
npm install
npm run lint
npm run build
```

لتشغيل نسخة الويب محليًا:

```bash
npm start
```

ثم افتح المنفذ `3000`.

لبناء Android APK بعد تثبيت Android SDK وGradle:

```bash
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```

يظهر الملف الناتج في:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## أماكن التعديل الرئيسية

- `src/App.tsx`: منطق التطبيق الرئيسي.
- `src/components/`: الشاشات والمكوّنات المرئية.
- `src/services/`: التخزين، التحديثات، البيانات، الإشعارات والصوت.
- `src/types/promosport.ts`: أنواع البيانات.
- `src/index.css`: التصميم العام.
- `public/`: الأيقونات وملفات PWA والبيانات الأولية.
- `capacitor.config.json`: إعدادات تطبيق Android.
- `android/`: مشروع Capacitor Android.

## ملاحظات مهمة

- لا تضع مفاتيح API أو كلمات مرور داخل الملفات المرفوعة.
- ملف `android/local.properties` غير مرفق لأنه يحتوي على مسار Android SDK خاص ببيئة البناء.
- بعد أي تعديل على الواجهة، شغّل `npm run lint` ثم `npm run build`.
- النسخة الحالية تم اختبارها: lint ناجح، build ناجح، والخادم يعيد HTTP 200.
