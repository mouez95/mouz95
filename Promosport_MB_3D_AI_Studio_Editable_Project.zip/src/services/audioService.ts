/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ClickSoundStyle, GoalSoundStyle } from '../types/promosport';

export const GOAL_SOUND_OPTIONS: ReadonlyArray<{
  id: GoalSoundStyle;
  label: string;
  durationLabel: string;
  durationSec: number;
  description: string;
}> = [
  {
    id: 'water-droplet',
    label: 'قطرة ماء مزدوجة',
    durationLabel: '0.7 ثانية',
    durationSec: 0.7,
    description: 'نغمة قطرة ماء واضحة بصدى ناعم',
  },
  {
    id: 'stadium-whistle',
    label: 'صافرة هدف والمدرجات',
    durationLabel: '1.5 ثانية',
    durationSec: 1.5,
    description: 'صافرة حكم حماسية مع رنين ملعب سريع',
  },
  {
    id: 'golden-chime',
    label: 'رنين ذهبي متلألئ',
    durationLabel: '2.2 ثانية',
    durationSec: 2.2,
    description: 'أجراس ذهبية متتابعة لاحتفالية الهدف',
  },
];

export const CLICK_SOUND_OPTIONS: ReadonlyArray<{
  id: ClickSoundStyle;
  label: string;
  durationLabel: string;
  description: string;
}> = [
  {
    id: 'soft-tap',
    label: 'نقرة ناعمة',
    durationLabel: '0.06 ث',
    description: 'صوت لمس خفيف وسريع',
  },
  {
    id: 'water-drop',
    label: 'قطرة خفيفة',
    durationLabel: '0.12 ث',
    description: 'نقطة ماء صغيرة عند كل نقرة',
  },
  {
    id: 'crystal-bell',
    label: 'رنين بلوري',
    durationLabel: '0.18 ث',
    description: 'نغمة بلورية قصيرة واضحة',
  },
];

class AudioService {
  private ctx: AudioContext | null = null;
  private soundEnabled: boolean = true;
  private goalSoundStyle: GoalSoundStyle = 'water-droplet';
  private clickSoundEnabled: boolean = true;
  private clickSoundStyle: ClickSoundStyle = 'soft-tap';
  private pendingAlertUntilMs: number = 0;
  private unlockListenerAttached: boolean = false;

  constructor() {
    // Lazy initialize upon user gesture
  }

  private attachUnlockReplayListener() {
    if (this.unlockListenerAttached || typeof window === 'undefined') return;
    this.unlockListenerAttached = true;
    const handleUnlock = () => {
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx
          .resume()
          .then(() => {
            if (Date.now() <= this.pendingAlertUntilMs) {
              this.pendingAlertUntilMs = 0;
              this.playNewGrilleAlert();
            }
          })
          .catch(() => {});
      }
      window.removeEventListener('pointerdown', handleUnlock);
      window.removeEventListener('keydown', handleUnlock);
      this.unlockListenerAttached = false;
    };
    window.addEventListener('pointerdown', handleUnlock, { once: true, passive: true });
    window.addEventListener('keydown', handleUnlock, { once: true, passive: true });
  }

  public setSoundEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
  }

  public setGoalSoundStyle(style: GoalSoundStyle) {
    this.goalSoundStyle = style;
  }

  public setClickSoundEnabled(enabled: boolean) {
    this.clickSoundEnabled = enabled;
  }

  public setClickSoundStyle(style: ClickSoundStyle) {
    this.clickSoundStyle = style;
  }

  public isEnabled(): boolean {
    return this.soundEnabled;
  }

  private getContext(bypassSoundEnabled = false): AudioContext | null {
    if (!bypassSoundEnabled && !this.soundEnabled) return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  /**
   * Notification sound chime (two cheerful harmonic bells)
   */
  public playChime() {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      const gain2 = ctx.createGain();

      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, now); // D5
      osc1.frequency.exponentialRampToValueAtTime(880, now + 0.15); // A5

      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(880, now + 0.15);
      osc2.frequency.exponentialRampToValueAtTime(1174.66, now + 0.35); // D6

      gain1.gain.setValueAtTime(0, now);
      gain1.gain.linearRampToValueAtTime(0.2, now + 0.05);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

      gain2.gain.setValueAtTime(0, now + 0.15);
      gain2.gain.linearRampToValueAtTime(0.25, now + 0.2);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.8);

      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);

      osc1.start(now);
      osc1.stop(now + 0.5);
      osc2.start(now + 0.15);
      osc2.stop(now + 0.8);
    } catch {
      // AudioContext policy fallback
    }
  }

  /**
   * Resonant golden ripple tone when clicking golden emblem
   */
  public playGoldenRipple() {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      // Synthesize a rich harmonic Tibetan bell / golden chime
      const fundamental = 432; // Harmonic sacred frequency
      const harmonics = [1, 2, 2.76, 5.4];
      const gains = [0.25, 0.12, 0.08, 0.04];

      harmonics.forEach((ratio, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = i === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(fundamental * ratio, now);

        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(gains[i], now + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.8 + i * 0.2);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + 2.0);
      });
    } catch {
      // ignore
    }
  }

  /**
   * UI click sound supporting 3 selectable styles + on/off toggle
   */
  public playClick(overrideStyle?: ClickSoundStyle) {
    if (!overrideStyle && (!this.soundEnabled || !this.clickSoundEnabled)) return;
    const style = overrideStyle || this.clickSoundStyle;
    const ctx = this.getContext(Boolean(overrideStyle));
    if (!ctx) return;

    try {
      const now = ctx.currentTime;

      if (style === 'water-drop') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(620, now);
        osc.frequency.exponentialRampToValueAtTime(1650, now + 0.085);
        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.18, now + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0005, now + 0.12);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.13);
        return;
      }

      if (style === 'crystal-bell') {
        const freqs = [1174.66, 1760];
        freqs.forEach((f, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const t = now + idx * 0.04;
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(f, t);
          gain.gain.setValueAtTime(0.001, t);
          gain.gain.linearRampToValueAtTime(0.14, t + 0.008);
          gain.gain.exponentialRampToValueAtTime(0.0004, t + 0.14);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(t);
          osc.stop(t + 0.15);
        });
        return;
      }

      // Default: 'soft-tap' (0.06s)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(300, now + 0.06);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.06);
    } catch {
      // ignore
    }
  }

  /**
   * Referee Whistle sound for match result announcement
   */
  public playWhistle() {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(2600, now);
      // vibrato
      const lfo = ctx.createOscillator();
      const lfoGain = ctx.createGain();
      lfo.frequency.setValueAtTime(24, now);
      lfoGain.gain.setValueAtTime(150, now);
      lfo.connect(osc.frequency);

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.15, now + 0.04);
      gain.gain.setValueAtTime(0.15, now + 0.25);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);

      lfo.start(now);
      osc.start(now);
      lfo.stop(now + 0.4);
      osc.stop(now + 0.4);
    } catch {
      // ignore
    }
  }

  /**
   * Synchronized 3D fiery circular portal flame whoosh + flying money/coin sparkle + landing chime
   */
  public playFieryMoneyBurst() {
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const sampleRate = ctx.sampleRate;

      // 1. Sub-bass page-shatter impact boom (0.0s -> 0.42s)
      const impactOsc = ctx.createOscillator();
      const impactGain = ctx.createGain();
      impactOsc.type = 'sine';
      impactOsc.frequency.setValueAtTime(135, now);
      impactOsc.frequency.exponentialRampToValueAtTime(34, now + 0.42);
      impactGain.gain.setValueAtTime(0.32, now);
      impactGain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
      impactOsc.connect(impactGain);
      impactGain.connect(ctx.destination);
      impactOsc.start(now);
      impactOsc.stop(now + 0.46);

      // 2. Swirling roaring flame buffer (0.05s -> 2.35s) rising as fiery circle fills screen
      const flameDuration = 2.4;
      const frameCount = Math.floor(sampleRate * flameDuration);
      const noiseBuffer = ctx.createBuffer(1, frameCount, sampleRate);
      const data = noiseBuffer.getChannelData(0);
      let lastOut = 0;
      for (let i = 0; i < frameCount; i++) {
        const white = Math.random() * 2 - 1;
        // Pink-brown fire turbulence noise
        lastOut = (lastOut + 0.06 * white) / 1.06;
        data[i] = lastOut * 3.4 + white * 0.28;
      }

      const noiseSrc = ctx.createBufferSource();
      noiseSrc.buffer = noiseBuffer;

      // Deep warm fire roar filter sweep
      const flameLowpass = ctx.createBiquadFilter();
      flameLowpass.type = 'lowpass';
      flameLowpass.Q.value = 1.8;
      flameLowpass.frequency.setValueAtTime(240, now);
      flameLowpass.frequency.exponentialRampToValueAtTime(1350, now + 1.35);
      flameLowpass.frequency.exponentialRampToValueAtTime(320, now + 2.3);

      // Flickering flame plasma bandpass + LFO modulation
      const flameBandpass = ctx.createBiquadFilter();
      flameBandpass.type = 'bandpass';
      flameBandpass.Q.value = 2.4;
      flameBandpass.frequency.setValueAtTime(550, now);
      flameBandpass.frequency.exponentialRampToValueAtTime(1850, now + 1.4);
      flameBandpass.frequency.exponentialRampToValueAtTime(600, now + 2.3);

      const flickerLfo = ctx.createOscillator();
      const flickerDepth = ctx.createGain();
      flickerLfo.frequency.setValueAtTime(11.5, now);
      flickerDepth.gain.setValueAtTime(240, now);
      flickerLfo.connect(flickerDepth);
      flickerDepth.connect(flameBandpass.frequency);

      const flameGain = ctx.createGain();
      flameGain.gain.setValueAtTime(0.001, now);
      flameGain.gain.linearRampToValueAtTime(0.28, now + 0.25);
      flameGain.gain.setValueAtTime(0.32, now + 1.45);
      flameGain.gain.exponentialRampToValueAtTime(0.001, now + 2.35);

      noiseSrc.connect(flameLowpass);
      noiseSrc.connect(flameBandpass);
      flameLowpass.connect(flameGain);
      flameBandpass.connect(flameGain);
      flameGain.connect(ctx.destination);

      flickerLfo.start(now);
      noiseSrc.start(now);
      flickerLfo.stop(now + flameDuration);
      noiseSrc.stop(now + flameDuration);

      // 3. Flying coins & crisp banknote sparkle cascade (0.04s -> 0.95s)
      const coinFreqs = [1975, 2637, 3136, 2349, 3520, 2793, 3951, 2093, 3322, 4186];
      coinFreqs.forEach((freq, idx) => {
        const t = now + 0.04 + idx * 0.055;
        const coinOsc = ctx.createOscillator();
        const coinGain = ctx.createGain();
        coinOsc.type = idx % 2 === 0 ? 'sine' : 'triangle';
        coinOsc.frequency.setValueAtTime(freq, t);
        coinOsc.frequency.exponentialRampToValueAtTime(freq * 1.12, t + 0.14);

        coinGain.gain.setValueAtTime(0.001, t);
        coinGain.gain.linearRampToValueAtTime(0.065, t + 0.012);
        coinGain.gain.exponentialRampToValueAtTime(0.0005, t + 0.22);

        coinOsc.connect(coinGain);
        coinGain.connect(ctx.destination);
        coinOsc.start(t);
        coinOsc.stop(t + 0.24);
      });

      // 4. Descending page golden triumph chime & soft settle (1.95s -> 2.95s)
      const settleNotes = [523.25, 659.25, 783.99, 1046.5];
      settleNotes.forEach((note, idx) => {
        const t = now + 1.92 + idx * 0.09;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = idx < 2 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(note, t);

        gain.gain.setValueAtTime(0.001, t);
        gain.gain.linearRampToValueAtTime(0.14, t + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.85);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(t + 0.88);
      });
    } catch {
      // AudioContext policy fallback
    }
  }

  /**
   * Prominent broadcast notification chime for new grille releases (works on open & wake from idle)
   */
  public playNewGrilleAlert() {
    const ctx = this.getContext();
    if (!ctx) return;

    if (ctx.state === 'suspended') {
      this.pendingAlertUntilMs = Date.now() + 9500;
      this.attachUnlockReplayListener();
      ctx.resume().catch(() => {});
      return;
    }

    try {
      const now = ctx.currentTime;
      const notes = [659.25, 880.0, 1174.66, 1567.98]; // E5 -> A5 -> D6 -> G6 sparkling fanfare
      notes.forEach((freq, idx) => {
        const start = now + idx * 0.11;
        const osc = ctx.createOscillator();
        const shimmerOsc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, start);

        shimmerOsc.type = 'triangle';
        shimmerOsc.frequency.setValueAtTime(freq * 2, start);

        gain.gain.setValueAtTime(0.001, start);
        gain.gain.linearRampToValueAtTime(0.24, start + 0.025);
        gain.gain.exponentialRampToValueAtTime(0.0008, start + 0.65);

        osc.connect(gain);
        shimmerOsc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(start);
        shimmerOsc.start(start);
        osc.stop(start + 0.68);
        shimmerOsc.stop(start + 0.68);
      });
    } catch {
      // ignore audio errors
    }
  }

  /**
   * Plays whichever goal alert sound style is active (or overridden for live preview)
   */
  public playGoalAlert(overrideStyle?: GoalSoundStyle) {
    const style = overrideStyle || this.goalSoundStyle;
    if (style === 'stadium-whistle') {
      this.playStadiumWhistleGoal(Boolean(overrideStyle));
      return;
    }
    if (style === 'golden-chime') {
      this.playGoldenChimeGoal(Boolean(overrideStyle));
      return;
    }
    this.playWaterDropletGoal(Boolean(overrideStyle));
  }

  /**
   * Choice 1 (0.7s): Clear double water-droplet alert with soft liquid echo
   */
  public playWaterDropletGoal(bypassSoundEnabled = false) {
    const ctx = this.getContext(bypassSoundEnabled);
    if (!ctx) return;

    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    try {
      const now = ctx.currentTime;

      const triggerDrop = (
        offsetSec: number,
        fStart: number,
        fEnd: number,
        dur: number,
        peakGain: number
      ) => {
        const start = now + offsetSec;
        const osc = ctx.createOscillator();
        const overtone = ctx.createOscillator();
        const filter = ctx.createBiquadFilter();
        const gain = ctx.createGain();
        const overtoneGain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(fStart, start);
        osc.frequency.exponentialRampToValueAtTime(fEnd, start + dur * 0.72);

        overtone.type = 'sine';
        overtone.frequency.setValueAtTime(fStart * 1.95, start);
        overtone.frequency.exponentialRampToValueAtTime(fEnd * 1.95, start + dur * 0.65);

        filter.type = 'bandpass';
        filter.frequency.setValueAtTime((fStart + fEnd) * 0.55, start);
        filter.Q.value = 3.2;

        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.linearRampToValueAtTime(peakGain, start + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0004, start + dur);

        overtoneGain.gain.setValueAtTime(0.0001, start);
        overtoneGain.gain.linearRampToValueAtTime(peakGain * 0.28, start + 0.006);
        overtoneGain.gain.exponentialRampToValueAtTime(0.0002, start + dur * 0.75);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        overtone.connect(overtoneGain);
        overtoneGain.connect(ctx.destination);

        osc.start(start);
        overtone.start(start);
        osc.stop(start + dur + 0.02);
        overtone.stop(start + dur + 0.02);
      };

      triggerDrop(0.0, 520, 1540, 0.13, 0.34);
      triggerDrop(0.11, 560, 1580, 0.11, 0.09);

      triggerDrop(0.21, 690, 2120, 0.15, 0.38);
      triggerDrop(0.36, 710, 2060, 0.13, 0.12);
      triggerDrop(0.52, 720, 1980, 0.11, 0.045);
    } catch {
      // ignore audio errors
    }
  }

  /**
   * Choice 2 (1.5s): Stadium goal whistle burst + triumphant chord swell
   */
  public playStadiumWhistleGoal(bypassSoundEnabled = false) {
    const ctx = this.getContext(bypassSoundEnabled);
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const bursts = [
        { start: 0.0, dur: 0.34, freq: 2720 },
        { start: 0.42, dur: 0.48, freq: 2860 },
      ];
      bursts.forEach((b) => {
        const t = now + b.start;
        const osc = ctx.createOscillator();
        const lfo = ctx.createOscillator();
        const lfoGain = ctx.createGain();
        const gain = ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(b.freq, t);
        lfo.frequency.setValueAtTime(28, t);
        lfoGain.gain.setValueAtTime(140, t);
        lfo.connect(lfoGain);
        lfoGain.connect(osc.frequency);

        gain.gain.setValueAtTime(0.001, t);
        gain.gain.linearRampToValueAtTime(0.14, t + 0.03);
        gain.gain.setValueAtTime(0.14, t + b.dur - 0.08);
        gain.gain.exponentialRampToValueAtTime(0.0005, t + b.dur);

        osc.connect(gain);
        gain.connect(ctx.destination);
        lfo.start(t);
        osc.start(t);
        lfo.stop(t + b.dur);
        osc.stop(t + b.dur);
      });

      // Warm stadium goal brass chord (0.75s -> 1.5s)
      [523.25, 659.25, 783.99].forEach((freq) => {
        const t = now + 0.72;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t);
        gain.gain.setValueAtTime(0.001, t);
        gain.gain.linearRampToValueAtTime(0.11, t + 0.06);
        gain.gain.exponentialRampToValueAtTime(0.0005, now + 1.5);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t);
        osc.stop(now + 1.52);
      });
    } catch {
      // ignore audio errors
    }
  }

  /**
   * Choice 3 (2.2s): Golden cascading celebratory chime
   */
  public playGoldenChimeGoal(bypassSoundEnabled = false) {
    const ctx = this.getContext(bypassSoundEnabled);
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const notes = [587.33, 739.99, 880, 1174.66, 1479.98, 1760];
      notes.forEach((freq, idx) => {
        const start = now + idx * 0.14;
        const osc = ctx.createOscillator();
        const over = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, start);
        over.type = 'triangle';
        over.frequency.setValueAtTime(freq * 1.5, start);

        gain.gain.setValueAtTime(0.001, start);
        gain.gain.linearRampToValueAtTime(0.18, start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0004, start + 1.35);

        osc.connect(gain);
        over.connect(gain);
        gain.connect(ctx.destination);
        osc.start(start);
        over.start(start);
        osc.stop(start + 1.38);
        over.stop(start + 1.38);
      });
    } catch {
      // ignore audio errors
    }
  }
}

export const audioService = new AudioService();

