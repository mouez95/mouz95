/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Trophy,
  Unlock,
  Lock,
  FolderArchive,
  Globe2,
  ChevronUp,
  ChevronDown,
  RefreshCw,
  Save,
  XCircle,
} from 'lucide-react';
import { PromosportGrille, WeeklyConcours } from '../types/promosport';
import { audioService } from '../services/audioService';

interface PromosportUnifiedBadgeProps {
  concours: WeeklyConcours;
  cagnotte: string;
  lang: 'AR' | 'FR';
  isKickoffStarted?: boolean;
  activeSubTab?: 'mondiale' | 'nationale' | 'slips';
  onSelectSubTab?: (tab: 'mondiale' | 'nationale' | 'slips') => void;
  slipsCount?: number;
  showTabs?: boolean;
  isOpen?: boolean;
  onToggleOpen?: (open: boolean) => void;
  tirageGrille?: PromosportGrille | null;
  onRefreshTirage?: () => void;
  isRefreshingTirage?: boolean;
  // Top combined betting controls (شريط تسجيل القصاصة مع إلغاء التحديد في نفس الشريط مع الجائزة الكبرى)
  showBettingControls?: boolean;
  totalSelections?: number;
  countDoubles?: number;
  countTriples?: number;
  combinationsCount?: number;
  formattedPriceTnd?: string;
  onSaveSlip?: () => void;
  onClearSelections?: () => void;
  transparentFloating?: boolean;
}

export const PromosportUnifiedBadge: React.FC<PromosportUnifiedBadgeProps> = ({
  concours,
  cagnotte,
  lang,
  isKickoffStarted = false,
  activeSubTab = 'mondiale',
  onSelectSubTab,
  slipsCount = 0,
  showTabs = true,
  isOpen: controlledIsOpen,
  onToggleOpen,
  tirageGrille = null,
  onRefreshTirage,
  isRefreshingTirage = false,
  showBettingControls = false,
  totalSelections = 0,
  countDoubles = 0,
  countTriples = 0,
  combinationsCount = 1,
  formattedPriceTnd = '0.400 DT',
  onSaveSlip,
  onClearSelections,
  transparentFloating = false,
}) => {
  const [internalIsOpen, setInternalIsOpen] = useState<boolean>(true);
  const isOpen = controlledIsOpen !== undefined ? controlledIsOpen : internalIsOpen;
  const setIsOpen = (next: boolean) => {
    if (onToggleOpen) {
      onToggleOpen(next);
    } else {
      setInternalIsOpen(next);
    }
  };

  const displayNumber = tirageGrille ? tirageGrille.number : concours.number;
  const displayDate = tirageGrille ? tirageGrille.date : concours.fullDateFormatted;
  const displayLocked = tirageGrille ? true : isKickoffStarted;
  const displayCagnotte = tirageGrille ? tirageGrille.cagnotteFormatted : cagnotte;

  // COLLAPSED STATE IN GRILLE OVERLAY: Centered Transparent Reopen Icon at Top Center
  if (!isOpen && transparentFloating) {
    return (
      <div className="w-full pt-1.5 px-2 flex items-center justify-center pointer-events-none">
        <button
          type="button"
          data-no-flash="true"
          onClick={() => {
            audioService.playClick();
            setIsOpen(true);
          }}
          title="فتح شريط الجائزة الكبرى وتسجيل القصاصة"
          aria-label="فتح الشريط العلوي يدوياً"
          className="pointer-events-auto min-h-[36px] px-3.5 py-1 rounded-full bg-gradient-to-r from-amber-400/25 via-black/25 to-amber-400/25 hover:from-amber-400/35 hover:to-amber-400/35 backdrop-blur-md border border-yellow-300/80 text-white shadow-[inset_0_0_12px_rgba(250,204,21,0.3),0_2px_14px_rgba(0,0,0,0.65)] flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
        >
          <Trophy className="w-3.5 h-3.5 text-yellow-300 shrink-0 drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)]" />
          <span className="text-[11px] font-black whitespace-nowrap drop-shadow-[0_1px_4px_rgba(0,0,0,0.98)]">
            {lang === 'AR' ? 'فتح الشريط' : 'Ouvrir'}
          </span>
          <ChevronDown className="w-3.5 h-3.5 text-yellow-300 shrink-0 drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)]" />
        </button>
      </div>
    );
  }

  return (
    <div
      className={`relative w-full ${
        transparentFloating ? 'px-1.5 sm:px-3 pt-1 pb-0.5 pointer-events-none' : 'px-2 sm:px-4 py-1.5 pointer-events-auto'
      } transition-all duration-200`}
    >
      {/* Frosted Golden Glass around the sides & perimeter (خلفية زجاجية مذهبة حول الجوانب ويمر تحتها هيكل المباريات) */}
      <div
        className={`pointer-events-auto relative rounded-2xl backdrop-blur-md bg-gradient-to-r from-amber-400/25 via-amber-100/[0.04] to-amber-400/25 border-2 border-amber-300/80 shadow-[inset_0_0_22px_rgba(251,191,36,0.34),0_6px_24px_rgba(245,158,11,0.28)] ${
          transparentFloating ? 'p-1.5 sm:p-2' : 'p-2 sm:p-2.5'
        } overflow-hidden transition-all duration-200`}
      >
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-inset ring-yellow-200/45 bg-gradient-to-b from-yellow-200/12 via-transparent to-amber-400/14"
        />
        <div className="relative z-10">
        {/* COLLAPSED STATE (Non-overlay tabs such as Tirage / Slips) */}
        {!isOpen ? (
          <div className="flex items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2">
              <div className="flex items-center -space-x-1.5">
                <div className="w-6 h-6 rounded-full bg-red-600 text-white font-black text-[10px] flex items-center justify-center border border-white">
                  1
                </div>
                <div className="w-6 h-6 rounded-full bg-amber-400 text-black font-black text-[10px] flex items-center justify-center border border-white">
                  X
                </div>
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white font-black text-[10px] flex items-center justify-center border border-white">
                  2
                </div>
              </div>

              {displayLocked ? (
                <div className="w-6 h-6 rounded-full bg-red-600/30 border border-red-400 flex items-center justify-center text-red-300" title="مقفل / منتهي">
                  <Lock className="w-3.5 h-3.5" />
                </div>
              ) : (
                <div className="w-6 h-6 rounded-full bg-emerald-500/30 border border-emerald-400 flex items-center justify-center text-emerald-300" title="متاح للتعمير">
                  <Unlock className="w-3.5 h-3.5" />
                </div>
              )}

              <span className="text-cyan-300 font-mono text-[11px] font-bold">#{displayNumber}</span>
            </div>

            <div className="flex items-center gap-1.5 px-2 sm:px-2.5 py-0.5 rounded-xl bg-amber-500/15 border border-yellow-400/60 min-w-0">
              <Trophy className="w-3.5 h-3.5 text-yellow-400 shrink-0" />
              <span className="font-mono text-[10px] min-[370px]:text-[11px] sm:text-xs font-black text-white truncate" dir="ltr">
                {tirageGrille
                  ? `${tirageGrille.cagnotteFormatted} • ${tirageGrille.winnersCount} • ${tirageGrille.prizePerWinnerFormatted}`
                  : displayCagnotte}
              </span>
            </div>

            <button
              type="button"
              onClick={() => {
                audioService.playClick();
                setIsOpen(true);
              }}
              className="shrink-0 flex items-center gap-1 px-2 sm:px-2.5 py-1 rounded-xl bg-yellow-400/20 hover:bg-yellow-400/30 border border-yellow-400/60 text-yellow-300 text-[11px] sm:text-xs font-black cursor-pointer active:scale-95 transition-all"
              title="فتح الشريط"
            >
              <span>فتح</span>
              <ChevronDown className="w-4 h-4 text-yellow-400" />
            </button>
          </div>
        ) : (
          /* EXPANDED STATE */
          <div className="flex flex-col gap-1.5">
            {/* ROW 1: Identity + Centered Grand Prize (شريط الجائزة الكبرى) + Close Button */}
            <div className="flex flex-wrap sm:flex-nowrap items-center justify-between gap-1.5 w-full">
              {/* Identity + Lock Status */}
              <div className="flex items-center gap-1.5 shrink-0">
                <div className="flex items-center -space-x-1.5 shrink-0">
                  <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-gradient-to-b from-red-500 to-red-700 border border-white text-white font-black text-[10px] sm:text-xs flex items-center justify-center z-30">
                    1
                  </div>
                  <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-gradient-to-b from-yellow-300 to-amber-500 border border-white text-black font-black text-[10px] sm:text-xs flex items-center justify-center z-20">
                    X
                  </div>
                  <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-gradient-to-b from-blue-600 to-blue-900 border border-white text-white font-black text-[10px] sm:text-xs flex items-center justify-center z-10">
                    2
                  </div>
                </div>

                <div className="shrink-0" title={displayLocked ? 'مقفل / منتهي' : 'متاح للتعمير'}>
                  {displayLocked ? (
                    <div className="w-6 h-6 rounded-full bg-red-600/35 border border-red-400 flex items-center justify-center text-red-200">
                      <Lock className="w-3.5 h-3.5" />
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-emerald-500/35 border border-emerald-300 flex items-center justify-center text-emerald-200">
                      <Unlock className="w-3.5 h-3.5" />
                    </div>
                  )}
                </div>

                <div className="text-right drop-shadow-[0_1px_4px_rgba(0,0,0,0.98)]">
                  <div className="flex items-center gap-1">
                    <span className="text-[11px] sm:text-xs font-black text-yellow-300 whitespace-nowrap">
                      {lang === 'AR' ? 'بروموسبور' : 'PROMOSPORT'}
                    </span>
                    <span className="text-cyan-300 font-mono text-[11px] font-black">
                      #{displayNumber}
                    </span>
                  </div>
                  <div className="text-[9.5px] text-gray-200 font-mono leading-none hidden min-[390px]:block" dir="ltr">
                    {displayDate}
                  </div>
                </div>
              </div>

              {/* CENTERED GRAND PRIZE CAGNOTTE */}
              <div className="flex items-center justify-center sm:mx-auto order-3 sm:order-2 w-full sm:w-auto">
                {tirageGrille ? (
                  <div className="flex items-center gap-2 bg-gradient-to-r from-amber-400/28 via-yellow-300/[0.06] to-amber-400/28 backdrop-blur-md border border-yellow-300/85 shadow-[inset_0_0_12px_rgba(250,204,21,0.32),0_2px_12px_rgba(245,158,11,0.28)] rounded-xl px-2.5 py-1 max-w-full drop-shadow-[0_1px_4px_rgba(0,0,0,0.95)]">
                    <Trophy className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
                    <div className="flex items-center gap-2 text-right min-w-0">
                      <div>
                        <span className="text-[8.5px] font-black text-yellow-300 block leading-none">
                          {lang === 'AR' ? 'القيمة المالية' : 'CAGNOTTE'}
                        </span>
                        <span className="font-mono text-[11px] font-black text-emerald-300" dir="ltr">
                          {tirageGrille.cagnotteFormatted}
                        </span>
                      </div>
                      <div className="h-5 w-px bg-yellow-400/40" />
                      <div>
                        <span className="text-[8.5px] font-black text-yellow-300 block leading-none">
                          {lang === 'AR' ? 'المرابيح' : 'GAGNANTS'}
                        </span>
                        <span className="font-mono text-[11px] font-black text-white">
                          {tirageGrille.winnersFormatted}
                        </span>
                      </div>
                      <div className="h-5 w-px bg-yellow-400/40" />
                      <div>
                        <span className="text-[8.5px] font-black text-yellow-300 block leading-none">
                          {lang === 'AR' ? 'النصيب' : 'PART'}
                        </span>
                        <span className="font-mono text-[11px] font-black text-yellow-200" dir="ltr">
                          {tirageGrille.prizePerWinnerFormatted}
                        </span>
                      </div>
                    </div>
                    {onRefreshTirage && (
                      <button
                        type="button"
                        onClick={() => {
                          audioService.playClick();
                          onRefreshTirage();
                        }}
                        title="تحديث من promosport-pronostic.com"
                        className="p-1 rounded-lg bg-yellow-400/20 hover:bg-yellow-400/40 border border-yellow-300/60 text-yellow-200 cursor-pointer active:scale-95 transition-all shrink-0"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingTirage ? 'animate-spin' : ''}`} />
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 bg-gradient-to-r from-amber-400/28 via-yellow-300/[0.06] to-amber-400/28 backdrop-blur-md border border-yellow-300/85 shadow-[inset_0_0_12px_rgba(250,204,21,0.32),0_2px_12px_rgba(245,158,11,0.28)] rounded-xl px-2.5 py-1 drop-shadow-[0_1px_5px_rgba(0,0,0,0.98)]">
                    <Trophy className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
                    <span className="text-[10px] font-black text-yellow-300 uppercase whitespace-nowrap">
                      {lang === 'AR' ? 'الجائزة الكبرى:' : 'CAGNOTTE:'}
                    </span>
                    <span className="font-mono text-xs sm:text-sm font-black text-white whitespace-nowrap" dir="ltr">
                      {cagnotte}
                    </span>
                  </div>
                )}
              </div>

              {/* Collapse Toggle Button */}
              <button
                type="button"
                data-no-flash="true"
                onClick={() => {
                  audioService.playClick();
                  setIsOpen(false);
                }}
                className="shrink-0 order-2 sm:order-3 min-w-[32px] min-h-[32px] p-1.5 rounded-xl bg-transparent hover:bg-white/15 border border-white/40 text-white cursor-pointer active:scale-95 transition-all flex items-center justify-center"
                title="إخفاء الشريط"
              >
                <ChevronUp className="w-4 h-4" />
              </button>
            </div>

            {/* ROW 2: Sub-tabs (القصاصة العالمية | القصاصة الوطنية | القصاصات) */}
            {showTabs && (
              <div className="shrink-0 flex items-center justify-center w-full">
                <div className="flex items-center justify-center flex-wrap sm:flex-nowrap gap-1.5 p-0.5 rounded-xl bg-transparent">
                  <button
                    type="button"
                    onClick={() => onSelectSubTab && onSelectSubTab('mondiale')}
                    className={`px-2.5 sm:px-3.5 py-1 rounded-xl text-[10.5px] sm:text-xs font-black transition-all flex items-center gap-1 cursor-pointer whitespace-nowrap active:scale-95 drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] ${
                      activeSubTab === 'mondiale'
                        ? 'bg-gradient-to-r from-cyan-400/90 via-sky-400/90 to-blue-500/90 text-black border border-yellow-300'
                        : 'text-white bg-transparent hover:bg-white/10 border border-yellow-400/80'
                    }`}
                  >
                    <Globe2 className="w-3.5 h-3.5 text-current shrink-0" />
                    <span>القصاصة العالمية</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onSelectSubTab && onSelectSubTab('nationale')}
                    className={`px-2.5 sm:px-3.5 py-1 rounded-xl text-[10.5px] sm:text-xs font-black transition-all flex items-center gap-1 cursor-pointer whitespace-nowrap active:scale-95 drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] ${
                      activeSubTab === 'nationale'
                        ? 'bg-gradient-to-r from-red-500/90 via-rose-600/90 to-red-700/90 text-white border border-yellow-300'
                        : 'text-white bg-transparent hover:bg-white/10 border border-yellow-400/80'
                    }`}
                  >
                    <span className="text-xs shrink-0">🇹🇳</span>
                    <span>القصاصة الوطنية</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onSelectSubTab && onSelectSubTab('slips')}
                    className={`px-2.5 sm:px-3.5 py-1 rounded-xl text-[10.5px] sm:text-xs font-black transition-all flex items-center gap-1 cursor-pointer whitespace-nowrap active:scale-95 drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] ${
                      activeSubTab === 'slips'
                        ? 'bg-gradient-to-r from-yellow-300/95 via-amber-400/95 to-yellow-500/95 text-black border border-white'
                        : 'text-yellow-200 bg-transparent hover:bg-white/10 border border-yellow-400/80'
                    }`}
                  >
                    <FolderArchive className="w-3.5 h-3.5 text-current shrink-0" />
                    <span>القصاصات ({slipsCount})</span>
                  </button>
                </div>
              </div>
            )}

            {/* ROW 3: TOP SAVE SLIP + CLEAR SELECTION + PRICING (شريط تسجيل القصاصة مع إلغاء التحديد في نفس الشريط) */}
            {showBettingControls && (
              <div className="pt-1 border-t border-white/20 flex flex-col gap-1.5 drop-shadow-[0_1px_4px_rgba(0,0,0,0.98)]">
                {isKickoffStarted ? (
                  <div className="flex items-center justify-between gap-2 text-[11px] font-bold text-amber-200 px-1">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <Lock className="w-3.5 h-3.5 text-red-400 shrink-0" />
                      <span className="truncate">التعمير مقفل تلقائياً — متابعة مباشرة للنتائج</span>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-0.5 text-[10.5px] sm:text-xs px-0.5">
                      <div className="flex items-center gap-2 font-bold text-white">
                        <span>
                          المباريات: <strong className="text-cyan-300 tabular-nums">{totalSelections}</strong>/13
                        </span>
                        <span>
                          ثنائيات: <strong className="text-yellow-300 tabular-nums">{countDoubles}</strong>
                        </span>
                        <span>
                          ثلاثيات: <strong className="text-yellow-300 tabular-nums">{countTriples}</strong>
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 font-mono">
                        <span className="text-gray-200 text-[10.5px] font-bold">
                          {combinationsCount} عمود
                        </span>
                        <span className="px-1.5 py-0.5 rounded-md bg-yellow-400 text-black font-black text-[10.5px]" dir="ltr">
                          {formattedPriceTnd}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={onSaveSlip}
                        disabled={isKickoffStarted}
                        className="min-h-[36px] py-1.5 px-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:brightness-105 text-black font-black text-xs shadow-[0_0_12px_rgba(16,185,129,0.65)] active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <Save className="w-3.5 h-3.5 shrink-0" />
                        <span>تسجيل القصاصة</span>
                      </button>

                      <button
                        type="button"
                        onClick={onClearSelections}
                        className="min-h-[36px] py-1.5 px-2.5 rounded-xl bg-[#e60067] hover:bg-pink-600 text-white font-black text-xs shadow-[0_0_12px_rgba(230,0,103,0.55)] active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <XCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>إلغاء التحديد</span>
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        )}
        </div>
      </div>
    </div>
  );
};
