/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  X,
  ArrowRight,
  Lock,
  Smartphone,
  LayoutGrid,
  Ticket,
  CheckCircle2,
  Trash2,
  Edit3,
  Save,
  Settings,
  Download,
  Check,
  FolderArchive,
  Coins,
  Receipt,
  Hash,
  Package,
  PhoneCall,
  CheckSquare,
  RefreshCw,
  KeyRound,
  Delete,
  Unlock,
  Bell,
  Radio,
} from 'lucide-react';
import {
  WeeklyConcours,
  WeeklyConcoursMatch,
  UserBetSlip,
  AppSettings,
  PromosportGrille,
} from '../types/promosport';
import {
  INITIAL_WEEKLY_CONCOURS,
  INITIAL_GRILLES,
  getOrderedRecentTirageGrilles,
} from '../services/promosportData';
import {
  loadUserSlips,
  saveOrUpdateSlip,
  deleteSlip,
  clearAllSlips,
  loadAppSettings,
  saveAppSettings,
  DEFAULT_APP_SETTINGS,
} from '../services/storageService';
import { calculatePromosportPrice } from '../services/pricingService';
import { evaluateConcoursRealTime } from '../services/matchLiveService';
import { audioService } from '../services/audioService';
import { MbLogo } from './MbLogo';
import { BroadcastScoreboardMatch } from './BroadcastScoreboardMatch';
import { PromosportUnifiedBadge } from './PromosportUnifiedBadge';
import { Grille3DWheelView } from './Grille3DWheelView';
import { SavedSlipFullPageView } from './SavedSlipFullPageView';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';
import { TirageFrozenSnapshotCard } from './TirageFrozenSnapshotCard';
import { AppInstallPromptHub } from './AppInstallPromptHub';
import { SaveSlipFieryPortal3D } from './SaveSlipFieryPortal3D';
import { LiveMatchesScanView } from './LiveMatchesScanView';

interface WeeklyConcoursModalProps {
  isOpen: boolean;
  onClose: () => void;
  concours: WeeklyConcours;
  onUpdateConcours?: (updated: WeeklyConcours) => void;
  grilles?: PromosportGrille[];
  onRefreshSync?: () => Promise<void> | void;
  initialTab?: 'grille' | 'tirage' | 'live' | 'settings' | 'apk';
  onTabChange?: (tab: 'grille' | 'tirage' | 'live' | 'settings' | 'apk') => void;
  appSettings?: AppSettings;
  onUpdateAppSettings?: (settings: AppSettings) => void;
  externalEntryPhase?: 'idle' | 'waiting' | 'descending';
  asMainPage?: boolean;
  onOpenNotifications?: () => void;
  hasUnreadAlerts?: boolean;
  onOpenIntroStage?: () => void;
}

// Arabic Team Name Translations
const ARABIC_TEAM_NAMES: Record<string, string> = {
  'Italie': 'إيطاليا',
  'France': 'فرنسا',
  'Turquie': 'تركيا',
  'Belgique': 'بلجيكا',
  'Tcheque': 'التشيك',
  'Espagne': 'إسبانيا',
  'Angleterre': 'إنجلترا',
  'Croatie': 'كرواتيا',
  'Albanie': 'ألبانيا',
  'Finlande': 'فنلندا',
  'Montenegro': 'الجبل الأسود',
  'Lettonie': 'لاتفيا',
  'Armenie': 'أرمينيا',
  'Chypre': 'قبرص',
  'Guinee Equatoriale': 'غينيا الاستوائية',
  'Zimbabwe': 'زيمبابوي',
  'Madagascar': 'مدغشقر',
  'Guinee Bissau': 'غينيا بيساو',
  'Cote D ivoire': 'كوت ديفوار',
  'Gambie': 'غامبيا',
  'RD Congo': 'الكونغو الديمقراطية',
  'Sierra Leone': 'سيراليون',
  'Benin': 'بنين',
  'Afrique Centrale': 'إفريقيا الوسطى',
  'Senegal': 'السنغال',
  'Soudan': 'السودان',
  // --- Concours 934 Teams ---
  'Portugal': 'البرتغال',
  'Danemark': 'الدنمارك',
  'Norvege': 'النرويج',
  'Pays de Galles': 'ويلز',
  'Irlande du Nord': 'أيرلندا الشمالية',
  'Ukraine': 'أوكرانيا',
  'Autriche': 'النمسا',
  'Irlande': 'أيرلندا',
  'Roumanie': 'رومانيا',
  'Pologne': 'بولندا',
  'Suede': 'السويد',
  'Bosnie herzegovine': 'البوسنة والهرسك',
  'Georgie': 'جورجيا',
  'Hongrie': 'المجر',
  'Ouganda': 'أوغندا',
  'Botswana': 'بوتسوانا',
  'Algerie': 'الجزائر',
  'Togo': 'توغو',
  'Real Oviedo': 'ريال أوفييدو',
  'Girona': 'جيرونا',
  'Mallorca': 'مايوركا',
  'Cordoba': 'قرطبة',
  'Real Sociedad B': 'ريال سوسيداد ب',
  'Sporting Gijon': 'سبورتينغ خيخون',
  'Almeria': 'ألميريا',
  'FC Andorra': 'أندورا',
  'CHELSEA': 'تشيلسي',
  'LOS ANGELES': 'لوس أنجلوس',
  'FLUMINENSE': 'فلومينينسي',
  'DORTMUND': 'بوروسيا دورتموند',
  'BOCA JUNIORS': 'بوكا جونيورز',
  'BENFICA': 'بنفيكا',
  'PRANCIS': 'فرنسا',
  'POLANDIA': 'بولندا',
  'GEORGIA': 'جورجيا',
  'PORTUGAL': 'البرتغال',
  // --- Concours 936 / 935 International Teams (promosport-pronostic.com) ---
  'Wales': 'ويلز',
  'Rep. Of Ireland': 'جمهورية أيرلندا',
  'Kosovo': 'كوسوفو',
  'Congo': 'الكونغو',
  'Comoros': 'جزر القمر',
  'Mauritania': 'موريتانيا',
  'Burkina Faso': 'بوركينا فاسو',
  'Rwanda': 'رواندا',
  'Mali': 'مالي',
  'Uganda': 'أوغندا',
  'Liberia': 'ليبيريا',
  'Cape Verde Islands': 'الرأس الأخضر',
  'Niger': 'النيجر',
  'Morocco': 'المغرب',
  'Maroc': 'المغرب',
  'Spain': 'إسبانيا',
  'England': 'إنجلترا',
  'Belgium': 'بلجيكا',
  'Italy': 'إيطاليا',
  'Türkiye': 'تركيا',
  'Turkey': 'تركيا',
  'Croatia': 'كرواتيا',
  'Czechia': 'التشيك',
  'Czech Republic': 'التشيك',
  'Belarus': 'بيلاروسيا',
  'Albania': 'ألبانيا',
  'Cyprus': 'قبرص',
  'Latvia': 'لاتفيا',
  'Armenia': 'أرمينيا',
  'Poland': 'بولندا',
  'Sweden': 'السويد',
  'Finland': 'فنلندا',
  'Austria': 'النمسا',
  'Romania': 'رومانيا',
  'Denmark': 'الدنمارك',
  'Norway': 'النرويج',
  'Hungary': 'المجر',
  'Georgia': 'جورجيا',
  'Northern Ireland': 'أيرلندا الشمالية',
  'Bosnia and Herzegovina': 'البوسنة والهرسك',
  'Bosnia & Herzegovina': 'البوسنة والهرسك',
  'Granada CF': 'غرناطة',
  'Las Palmas': 'لاس بالماس',
  'Eibar': 'إيبار',
  'Cadiz': 'قادش',
  'Eldense': 'إلدينسي',
  'Sabadell': 'ساباديل',
  'Tenerife': 'تينيريفي',
  'AD Ceuta FC': 'سبتة',
  'Ceuta': 'سبتة',
};

const PROTECTED_TABS_PIN = '1777';

export const WeeklyConcoursModal: React.FC<WeeklyConcoursModalProps> = ({
  isOpen,
  onClose,
  concours,
  grilles = INITIAL_GRILLES,
  onRefreshSync,
  initialTab = 'grille',
  onTabChange,
  appSettings: initialAppSettings,
  onUpdateAppSettings,
  externalEntryPhase = 'idle',
  asMainPage = false,
  onOpenNotifications,
  hasUnreadAlerts = false,
  onOpenIntroStage,
}) => {
  const onRefreshSyncRef = useRef(onRefreshSync);
  onRefreshSyncRef.current = onRefreshSync;
  const lastTirageAutoSyncMsRef = useRef<number>(0);

  // Active competition synced from parent concours (default international Concours No 936)
  const [activeConcours, setActiveConcours] = useState<WeeklyConcours>(
    concours || INITIAL_WEEKLY_CONCOURS
  );
  const prevConcoursNumRef = useRef<number>((concours || INITIAL_WEEKLY_CONCOURS).number);

  useEffect(() => {
    if (concours) {
      if (prevConcoursNumRef.current !== concours.number) {
        // Silent rollover: reset temporary selections when a new concours arrives
        setCurrentSelections({});
        setEditingSlipId(null);
        prevConcoursNumRef.current = concours.number;
      }
      setActiveConcours(concours);
    }
  }, [concours]);

  // Bottom navigation: 'grille' | 'tirage' | 'live' | 'apk' (Settings lives inside 'apk' as an unlocked sub-page)
  const [activeBottomNav, setActiveBottomNav] = useState<'grille' | 'tirage' | 'live' | 'apk'>(
    initialTab === 'settings' ? 'apk' : initialTab
  );
  const [liveBadgeCount, setLiveBadgeCount] = useState<number>(0);
  const [promptSubPage, setPromptSubPage] = useState<'hub' | 'settings'>(
    initialTab === 'settings' ? 'settings' : 'hub'
  );
  const prevInitialTabRef = useRef(initialTab);

  // Password lock (PIN: 1777) protecting only the Prompt/APK hub (Settings sub-page opens freely without PIN)
  const [isProtectedTabsUnlocked, setIsProtectedTabsUnlocked] = useState<boolean>(false);
  const [pinInput, setPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);

  // Only the single most recent previous grille (e.g. 935 while 936 is active), shown even before official payouts publish
  const recentGrilles = useMemo(
    () => getOrderedRecentTirageGrilles(grilles, activeConcours.number),
    [grilles, activeConcours.number]
  );

  const activeTirage = recentGrilles[0];

  const [isRefreshingTirage, setIsRefreshingTirage] = useState<boolean>(false);

  const handleRefreshTirageFromSite = async () => {
    if (isRefreshingTirage) return;
    setIsRefreshingTirage(true);
    try {
      if (onRefreshSyncRef.current) {
        await onRefreshSyncRef.current();
      }
    } finally {
      setIsRefreshingTirage(false);
    }
  };

  const isTirageOfficialFrozen = Boolean(
    activeTirage &&
      activeTirage.status === 'official' &&
      activeTirage.winnersFormatted !== 'قيد التحديد الرسمي'
  );

  // Throttled payout-only check when opening Tirage IF payouts have NOT yet published
  // Once official payouts appear, stop refreshing and leave Tirage frozen as a static image
  useEffect(() => {
    if (!isOpen || activeBottomNav !== 'tirage' || !onRefreshSyncRef.current) return;
    if (isTirageOfficialFrozen) return;
    const now = Date.now();
    if (now - lastTirageAutoSyncMsRef.current < 8000) return;
    lastTirageAutoSyncMsRef.current = now;
    void onRefreshSyncRef.current();
  }, [isOpen, activeBottomNav, isTirageOfficialFrozen]);

  // Sub-tabs in Grille view: 'mondiale' | 'nationale' | 'slips'
  const [grilleSubTab, setGrilleSubTab] = useState<'mondiale' | 'nationale' | 'slips'>('mondiale');

  // National check states (when no national concours is published)
  const [isCheckingNational, setIsCheckingNational] = useState<boolean>(false);
  const [lastNationalCheckTime, setLastNationalCheckTime] = useState<string>('اليوم (تحديث مستمر)');

  const handleRefreshNational = async () => {
    audioService.playClick();
    setIsCheckingNational(true);
    try {
      if (onRefreshSync) {
        await onRefreshSync();
      }
    } finally {
      setIsCheckingNational(false);
      const timeStr = new Date().toLocaleTimeString('ar-TN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastNationalCheckTime(`اليوم في ${timeStr}`);
      audioService.playChime();
      setSlipNoticeMessage(
        'تم التحقق بنجاح من موقع promosport-pronostic.com — القصاصة الوطنية غير منشورة حالياً.'
      );
      setTimeout(() => setSlipNoticeMessage(null), 4000);
    }
  };

  // Language toggle: AR / FR
  const [lang, setLang] = useState<'AR' | 'FR'>('AR');

  // Floating glass ribbon open/close state in Grille (auto-closes on scroll, opens manually)
  const [isGrilleRibbonOpen, setIsGrilleRibbonOpen] = useState<boolean>(true);

  const triggerGrilleIconFlash = (e: React.MouseEvent<HTMLDivElement>) => {
    if (activeBottomNav !== 'grille' || selectedFullSlip) return;
    const targetEl = (e.target as HTMLElement | null)?.closest(
      'button, [role="button"], [data-flash-icon]'
    ) as HTMLElement | null;
    if (!targetEl || targetEl.dataset.noFlash === 'true') return;

    window.requestAnimationFrame(() => {
      targetEl.classList.remove('grille-icon-flash');
      targetEl.classList.add('grille-icon-flash');
      window.setTimeout(() => {
        targetEl.classList.remove('grille-icon-flash');
      }, 260);
    });
  };

  // App Settings state
  const [settings, setSettings] = useState<AppSettings>(() => initialAppSettings || loadAppSettings());
  const [settingsSavedAlert, setSettingsSavedAlert] = useState<boolean>(false);

  // Slips from storage (strictly NO virtual/dummy slips)
  const [userSlips, setUserSlips] = useState<UserBetSlip[]>(() => loadUserSlips());
  const [editingSlipId, setEditingSlipId] = useState<string | null>(null);
  const [slipNoticeMessage, setSlipNoticeMessage] = useState<string | null>(null);

  // 3D Save Slip Transition: 'idle' -> 'bursting' (page shatters w/ money & fiery portal opens) -> 'descending' (fresh page drops from top)
  const [saveTransitionPhase, setSaveTransitionPhase] = useState<'idle' | 'bursting' | 'descending'>('idle');
  const [showFierySavePortal, setShowFierySavePortal] = useState<boolean>(false);
  const saveTransitionTimersRef = useRef<number[]>([]);

  useEffect(() => {
    if (!isOpen) {
      saveTransitionTimersRef.current.forEach((id) => window.clearTimeout(id));
      saveTransitionTimersRef.current = [];
      setSaveTransitionPhase('idle');
      setShowFierySavePortal(false);
    }
    return () => {
      saveTransitionTimersRef.current.forEach((id) => window.clearTimeout(id));
      saveTransitionTimersRef.current = [];
    };
  }, [isOpen]);

  // Selected choices map: matchId -> array of choices ('1' | 'X' | '2')
  const [currentSelections, setCurrentSelections] = useState<Record<number, ('1' | 'X' | '2')[]>>({});

  // Expanded slip in Saved Slips page
  const [expandedSlipId, setExpandedSlipId] = useState<string | null>(null);
  // Full-page active slip view
  const [selectedFullSlip, setSelectedFullSlip] = useState<UserBetSlip | null>(null);

  const [goalFlashMatchIds, setGoalFlashMatchIds] = useState<Record<number, number>>({});
  const prevScoresRef = useRef<Record<number, { h: number; a: number; hasScore: boolean; status: string }> | null>(null);

  // Real-time evaluated concours (re-evaluates cleanly whenever live feed updates activeConcours)
  const liveConcours = useMemo(
    () => evaluateConcoursRealTime(activeConcours, Date.now(), null),
    [activeConcours]
  );

  // Resolve exact concours (active live or archived Tirage) matching a saved slip's grilleNumber
  const resolveConcoursForSlip = (slip: UserBetSlip): WeeklyConcours => {
    if (slip.grilleNumber === liveConcours.number) {
      return liveConcours;
    }
    const archived = grilles.find((g) => g.number === slip.grilleNumber);
    if (!archived) {
      return liveConcours;
    }
    return {
      number: archived.number,
      category: 'international',
      title: `Concours International N° ${archived.number}`,
      season: liveConcours.season || 'Saison 2026-2027',
      fullDateFormatted: archived.date,
      dateStr: archived.date.split(' ')[0] || archived.date,
      closingTimeStr: archived.date.split('à ')[1] || '15:00',
      cagnotteEstimate: archived.cagnotteFormatted,
      sourceUrl: archived.sourceUrl || liveConcours.sourceUrl,
      matches: archived.matches.map((m) => {
        const scoreMatch = String(m.score || '').match(/^(\d+)\s*[-:]\s*(\d+)$/);
        const hasValidScore = Boolean(scoreMatch);
        return {
          id: m.id,
          homeTeam: m.homeTeam,
          homeTeamFr: m.homeTeamFr,
          homeLogo: m.homeLogo || 'CLUB',
          awayTeam: m.awayTeam,
          awayTeamFr: m.awayTeamFr,
          awayLogo: m.awayLogo || 'CLUB',
          date: archived.date.split(' ')[0] || archived.date,
          time: archived.date.split('à ')[1] || '',
          dayTime: archived.date.split('à ')[1] || '',
          kickoffTimestamp: 0,
          status: hasValidScore ? ('finished' as const) : ('scheduled' as const),
          score: hasValidScore ? `${scoreMatch![1]} - ${scoreMatch![2]}` : '- - -',
          scoreHome: hasValidScore ? scoreMatch![1] : undefined,
          scoreAway: hasValidScore ? scoreMatch![2] : undefined,
          competition: m.competition || `المسابقة العالمية #${archived.number}`,
          competitionFr: m.competitionFr || `CONCOURS INT #${archived.number}`,
          result: hasValidScore ? m.result : null,
          prob1: 40,
          probX: 30,
          prob2: 30,
        };
      }),
    };
  };

  // Detect live goal scored: 7s blazing flame + shake + water droplet chime (strictly verified scores only)
  useEffect(() => {
    const nextScores: Record<number, { h: number; a: number; hasScore: boolean; status: string }> = {};
    const scoredNow: number[] = [];

    liveConcours.matches.forEach((m) => {
      const hasScore =
        !m.isDelayed &&
        m.scoreHome !== undefined &&
        m.scoreAway !== undefined &&
        /^\d+$/.test(String(m.scoreHome)) &&
        /^\d+$/.test(String(m.scoreAway));
      const h = hasScore ? Number(m.scoreHome) : 0;
      const a = hasScore ? Number(m.scoreAway) : 0;
      nextScores[m.id] = { h, a, hasScore, status: m.status };

      const prev = prevScoresRef.current?.[m.id];
      if (
        prev &&
        hasScore &&
        (m.status === 'live' || (prev.status === 'live' && m.status === 'finished')) &&
        ((prev.hasScore && (h > prev.h || a > prev.a)) || (!prev.hasScore && (h > 0 || a > 0)))
      ) {
        scoredNow.push(m.id);
      }
    });

    prevScoresRef.current = nextScores;

    if (scoredNow.length > 0) {
      audioService.playGoalAlert();
      const stamp = Date.now();
      setGoalFlashMatchIds((prev) => {
        const updated = { ...prev };
        scoredNow.forEach((id) => {
          updated[id] = stamp;
        });
        return updated;
      });
      scoredNow.forEach((id) => {
        window.setTimeout(() => {
          setGoalFlashMatchIds((prev) => {
            if (prev[id] !== stamp) return prev;
            const copy = { ...prev };
            delete copy[id];
            return copy;
          });
        }, 7000);
      });
    }
  }, [liveConcours]);

  // Automatic betting & editing lock:
  // Locked automatically from kickoff of the 1st match until end of last match / appearance of a new concours.
  const hasFirstMatchStarted = useMemo(
    () => liveConcours.matches.some((m) => m.status === 'live' || m.status === 'finished'),
    [liveConcours]
  );
  const isBettingLocked = hasFirstMatchStarted;

  // Sync external settings without resetting active user tab
  useEffect(() => {
    if (isOpen && initialAppSettings) {
      setSettings(initialAppSettings);
    }
  }, [isOpen, initialAppSettings]);

  // Sync tab only when modal opens or parent explicitly changes initialTab
  useEffect(() => {
    if (isOpen) {
      setUserSlips(loadUserSlips());
      if (prevInitialTabRef.current !== initialTab) {
        prevInitialTabRef.current = initialTab;
        if (initialTab === 'settings') {
          setActiveBottomNav('apk');
          setPromptSubPage('settings');
        } else if (initialTab) {
          setActiveBottomNav(initialTab);
          if (initialTab === 'apk') {
            setPromptSubPage('hub');
          }
        }
        setPinError(null);
      }
    } else {
      setIsProtectedTabsUnlocked(false);
      setPinInput('');
      setPinError(null);
    }
  }, [isOpen, initialTab]);

  const handlePinChange = (rawValue: string) => {
    const cleaned = rawValue.replace(/\D/g, '').slice(0, 6);
    setPinInput(cleaned);
    if (cleaned === PROTECTED_TABS_PIN) {
      audioService.playChime();
      setIsProtectedTabsUnlocked(true);
      setPinInput('');
      setPinError(null);
      return;
    }
    if (cleaned.length >= 4) {
      setPinError('كلمة السر غير صحيحة — أدخل 1777 لفتح الخانة');
    } else {
      setPinError(null);
    }
  };

  const handlePinSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    audioService.playClick();
    if (pinInput === PROTECTED_TABS_PIN) {
      audioService.playChime();
      setIsProtectedTabsUnlocked(true);
      setPinInput('');
      setPinError(null);
    } else {
      setPinError('كلمة السر غير صحيحة — الرجاء إدخال 1777');
      setPinInput('');
    }
  };

  if (!isOpen) return null;

  // Calculate doubles and triples in current selections
  let countDoubles = 0;
  let countTriples = 0;
  let totalSelections = 0;

  Object.values(currentSelections).forEach((sel) => {
    if (sel && sel.length > 0) {
      totalSelections++;
      if (sel.length === 2) countDoubles++;
      if (sel.length === 3) countTriples++;
    }
  });

  // Calculate pricing using settings rates
  const pricing = calculatePromosportPrice(
    countDoubles,
    countTriples,
    settings.columnRate,
    settings.baseFee
  );

  // Helper to translate team names
  const getTeamName = (teamName: string, frName?: string) => {
    if (lang === 'AR') {
      return ARABIC_TEAM_NAMES[teamName] || ARABIC_TEAM_NAMES[frName || ''] || teamName;
    }
    return frName || teamName;
  };

  const showTemporaryNotice = (msg: string) => {
    setSlipNoticeMessage(msg);
    setTimeout(() => {
      setSlipNoticeMessage(null);
    }, 4000);
  };

  // Toggle match choice
  const toggleSelection = (matchId: number, sign: '1' | 'X' | '2') => {
    if (isBettingLocked) {
      audioService.playClick();
      showTemporaryNotice('تم قفل تعمير وتعديل القصاصات تلقائياً من بداية أول مقابلة حتى نهاية آخر المقابلات.');
      return;
    }
    audioService.playClick();

    setCurrentSelections((prev) => {
      const current = prev[matchId] || [];
      let updated: ('1' | 'X' | '2')[];

      if (current.includes(sign)) {
        updated = current.filter((s) => s !== sign);
      } else {
        updated = [...current, sign];
      }

      return {
        ...prev,
        [matchId]: updated,
      };
    });
  };

  // Clear selections
  const handleClearSelections = () => {
    audioService.playClick();
    setCurrentSelections({});
    setEditingSlipId(null);
  };

  // Save current slip with 3D exploding money shower, fiery rotating full-screen beam, and fresh page descent
  const handleSaveSlip = () => {
    if (saveTransitionPhase !== 'idle') return;
    if (isBettingLocked) {
      audioService.playClick();
      showTemporaryNotice('تم قفل تسجيل وتعديل القصاصات تلقائياً عند بداية أول مقابلة حتى نهاية آخر المقابلات.');
      return;
    }
    if (totalSelections < 13) {
      audioService.playClick();
      showTemporaryNotice(`الرجاء إكمال تعمير الـ 13 مباراة لحفظ القصاصة (المكتملة حالياً: ${totalSelections} / 13).`);
      return;
    }

    const nextSlipNumber = userSlips.length + 1;
    const nowDate = new Date();
    const nowClock = nowDate.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const newSlip: UserBetSlip = {
      id: editingSlipId || `slip-${Date.now()}`,
      grilleNumber: activeConcours.number,
      name: `قصاصة مسجلة رقم ${nextSlipNumber}`,
      createdAt: nowDate.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }) + ' ' + nowClock.slice(0, 5),
      updatedAt: nowClock,
      selections: currentSelections,
      betType: countTriples > 0 ? 'triple' : countDoubles > 0 ? 'double' : 'single',
      totalCombinations: pricing.combinations,
      totalCostDt: pricing.priceTnd,
      isLocked: isBettingLocked,
    };

    const updated = saveOrUpdateSlip(newSlip);
    setUserSlips(updated);

    // Clear any leftover timers before starting cinematic 3D transition
    saveTransitionTimersRef.current.forEach((id) => window.clearTimeout(id));
    saveTransitionTimersRef.current = [];

    // Play synchronized roaring flame + shattering money sparkles + settle chime
    audioService.playFieryMoneyBurst();
    setShowFierySavePortal(true);
    setSaveTransitionPhase('bursting');

    // Phase 2 (~1900ms): Swap to fresh empty slip and drop normal page down from the top while beam dissolves
    const tDescend = window.setTimeout(() => {
      setCurrentSelections({});
      setEditingSlipId(null);
      setActiveBottomNav('grille');
      setGrilleSubTab('mondiale');
      setSelectedFullSlip(null);
      setSaveTransitionPhase('descending');
    }, 1900);

    // Phase 3 (~3100ms): Settle page to normal natural position and dispose 3D portal
    const tFinish = window.setTimeout(() => {
      setSaveTransitionPhase('idle');
      setShowFierySavePortal(false);
      showTemporaryNotice(`تم تسجيل القصاصة بنجاح! تم فتح تعمير قصاصة جديدة فارغة رقم ${updated.length + 1}`);
    }, 3100);

    saveTransitionTimersRef.current.push(tDescend, tFinish);
  };

  // Delete saved slip (immediately without blocking confirm dialog in iframe)
  const handleDeleteSlip = (slipId: string) => {
    audioService.playClick();
    const updated = deleteSlip(slipId);
    setUserSlips(updated);
    if (editingSlipId === slipId) {
      setEditingSlipId(null);
      setCurrentSelections({});
    }
    if (expandedSlipId === slipId) {
      setExpandedSlipId(updated.length > 0 ? updated[0].id : null);
    }
    setSlipNoticeMessage('تم فسخ القصاصة بنجاح من السجل!');
    setTimeout(() => {
      setSlipNoticeMessage(null);
    }, 3000);
  };

  // Delete all saved slips
  const handleClearAllSlips = () => {
    audioService.playClick();
    const updated = clearAllSlips();
    setUserSlips(updated);
    setEditingSlipId(null);
    setCurrentSelections({});
    setExpandedSlipId(null);
    setSlipNoticeMessage('تم فسخ جميع القصاصات بنجاح من السجل!');
    setTimeout(() => {
      setSlipNoticeMessage(null);
    }, 3000);
  };

  // Edit saved slip (only before first kickoff!)
  const handleEditSlip = (slip: UserBetSlip) => {
    if (isBettingLocked) {
      audioService.playClick();
      showTemporaryNotice('لا يمكن تعديل أي قصاصة عند بداية أول مقابلة حتى نهاية آخر المقابلات (يُسمح بالفسخ فقط).');
      return;
    }
    audioService.playClick();
    setEditingSlipId(slip.id);
    setCurrentSelections(slip.selections);
    setActiveBottomNav('grille');
    setGrilleSubTab('mondiale');
  };

  // Save Settings handler
  const handleSaveAppSettings = () => {
    audioService.playClick();
    saveAppSettings(settings);
    if (onUpdateAppSettings) {
      onUpdateAppSettings(settings);
    }
    audioService.playChime();
    setSettingsSavedAlert(true);
    setTimeout(() => setSettingsSavedAlert(false), 3000);
  };

  // Reset Settings handler
  const handleResetAppSettings = () => {
    audioService.playClick();
    setSettings(DEFAULT_APP_SETTINGS);
    saveAppSettings(DEFAULT_APP_SETTINGS);
    if (onUpdateAppSettings) {
      onUpdateAppSettings(DEFAULT_APP_SETTINGS);
    }
  };

  // Render National Unavailable view with exact screenshot and refresh button
  const renderNationalUnavailableView = () => {
    return (
      <div className="flex flex-col items-center justify-center p-2 sm:p-4 text-center space-y-4 animate-fade-in max-w-lg mx-auto">
        {/* Exact official screenshot from user: Screenshot_20261103_235250_Chrome_4fcf597e.jpg */}
        <div className="relative group w-full max-w-[340px] sm:max-w-[360px] rounded-3xl overflow-hidden border-2 border-yellow-400/90 shadow-[0_0_35px_rgba(234,179,8,0.5)] bg-[#030918]">
          <img
            src="/assets/aistudio/Screenshot_20261103_235250_Chrome_4fcf597e.jpg"
            alt="Aucun match national dans ce tirage - Promosport Tunisie"
            className="w-full h-auto object-contain block select-none"
          />
          <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black/30 via-transparent to-white/10" />
        </div>

        {/* Interactive "تحديث جديد" (Refresh) Button & Status */}
        <div className="w-full max-w-[360px] space-y-2.5">
          <button
            onClick={handleRefreshNational}
            disabled={isCheckingNational}
            className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 hover:from-yellow-300 hover:to-amber-400 text-black font-black text-xs sm:text-sm shadow-[0_0_25px_rgba(241,184,22,0.85)] active:scale-95 transition-all flex items-center justify-center gap-2.5 disabled:opacity-70 cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${isCheckingNational ? 'animate-spin' : ''}`} />
            <span>{isCheckingNational ? 'جارٍ فحص promosport-pronostic.com...' : 'تحديث جديد وفحص المسابقة الوطنية'}</span>
          </button>

          {/* Live notification box */}
          <div className="p-3 rounded-2xl bg-black/75 border border-yellow-500/40 text-right text-[11px] text-gray-300 space-y-1.5 shadow-md">
            <div className="flex items-center justify-between text-yellow-300 font-bold">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
                <span>حالة المسابقة الوطنية:</span>
              </span>
              <span className="font-mono text-[10px] text-cyan-300" dir="ltr">{lastNationalCheckTime}</span>
            </div>
            <p className="text-[10px] text-gray-400 leading-relaxed">
              الموقع المعتمد <strong className="text-white">promosport-pronostic.com/welcome/promosport</strong> يظهر القصاصة العالمية الحالية فقط (المسابقة {liveConcours.number}). لا توجد مسابقة للبطولة الوطنية منشورة حالياً.
            </p>
          </div>

          {/* Quick link button to switch to International Grille */}
          <button
            onClick={() => {
              audioService.playClick();
              setActiveConcours(concours || INITIAL_WEEKLY_CONCOURS);
              setGrilleSubTab('mondiale');
            }}
            className="w-full py-2.5 px-3 rounded-xl bg-sky-950/70 hover:bg-sky-900/80 border border-sky-400/60 text-cyan-300 font-bold text-xs transition-colors flex items-center justify-center gap-2"
          >
            <span>الانتقال إلى القصاصة العالمية {liveConcours.number} المتاحة</span>
          </button>
        </div>
      </div>
    );
  };

  return (
    <div
      role={asMainPage ? 'main' : 'dialog'}
      aria-modal={asMainPage ? undefined : true}
      className={`fixed inset-0 ${
        asMainPage ? 'z-20 bg-[#020612]' : 'z-50 bg-black/95 animate-fade-in'
      } flex items-center justify-center p-0 sm:p-2 font-sans select-none overflow-hidden`}
    >
      {/* 3D Fiery Rotating Luminous Beam + Flying Money Burst Overlay (mounts only during active save transition) */}
      <SaveSlipFieryPortal3D active={showFierySavePortal} />

      {/* 3D Broadcast Stadium Shell Container - Fully responsive for all mobile screens */}
      <div
        onClickCapture={triggerGrilleIconFlash}
        className={`relative flex flex-col bg-[#050e20] border-0 sm:border-2 sm:border-sky-400/80 shadow-[0_0_80px_rgba(56,189,248,0.5)] overflow-hidden transition-all duration-300 w-full max-w-2xl sm:max-w-3xl modal-h-full sm:rounded-3xl ${
          saveTransitionPhase === 'bursting'
            ? 'slip-page-explode pointer-events-none'
            : saveTransitionPhase === 'descending' || externalEntryPhase === 'descending'
              ? 'slip-page-descend'
              : externalEntryPhase === 'waiting'
                ? 'opacity-0'
                : ''
        }`}
      >
        {/* CONDITIONAL: FULL SLIP PAGE VIEW OR REGULAR MODAL BODY */}
        {selectedFullSlip ? (
          <SavedSlipFullPageView
            slip={selectedFullSlip}
            concours={resolveConcoursForSlip(selectedFullSlip)}
            lang={lang}
            onBackToSlips={() => {
              setSelectedFullSlip(null);
              setActiveBottomNav('grille');
              setGrilleSubTab('slips');
            }}
            onBackToGrille={() => {
              setSelectedFullSlip(null);
              setActiveBottomNav('grille');
              setActiveConcours(concours || INITIAL_WEEKLY_CONCOURS);
              setGrilleSubTab('mondiale');
            }}
            onUpdateSlip={(updatedSlip) => {
              const updated = saveOrUpdateSlip(updatedSlip);
              setUserSlips(updated);
              setSelectedFullSlip(updatedSlip);
            }}
            onDeleteSlip={(slipId) => {
              handleDeleteSlip(slipId);
              setSelectedFullSlip(null);
            }}
            getTeamName={getTeamName}
            isKickoffStarted={isBettingLocked}
            columnRate={settings.columnRate}
            baseFee={settings.baseFee}
            goalFlashMatchIds={goalFlashMatchIds}
          />
        ) : (
          <>
            {/* 1. TOP HEADER WITH MB LOGO (LEFT) & 50% SCALED GOLDEN BOX (RIGHT) */}
            <div className="shrink-0 px-2.5 sm:px-5 pt-[max(0.5rem,env(safe-area-inset-top))] pb-2 sm:py-2.5 bg-gradient-to-r from-[#040a18] via-[#091a38] to-[#040a18] border-b border-yellow-500/50 flex items-center justify-between gap-2 shadow-md">
              
              {/* MB LOGO (Click -> opens opening showcase page) + NOTIFICATION SYSTEM ICON BESIDE IT */}
              <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    onOpenIntroStage?.();
                  }}
                  title="فتح واجهة التطبيق التقديمية"
                  aria-label="فتح واجهة التطبيق التقديمية"
                  className="rounded-full p-0.5 cursor-pointer hover:scale-105 active:scale-95 transition-transform focus:outline-none"
                >
                  <MbLogo size="md" showLaser={true} />
                </button>
                {onOpenNotifications ? (
                  <button
                    type="button"
                    onClick={() => {
                      audioService.playClick();
                      onOpenNotifications();
                    }}
                    title="منظومة التنبيهات والتحديث التلقائي"
                    className="relative group min-w-[44px] min-h-[44px] p-2 sm:p-2.5 rounded-xl bg-gradient-to-br from-yellow-500/20 via-amber-900/40 to-slate-900 border-2 border-yellow-400/85 text-yellow-300 hover:text-yellow-100 hover:border-yellow-300 shadow-[0_0_16px_rgba(250,204,21,0.5)] active:scale-95 transition-all cursor-pointer flex items-center justify-center"
                  >
                    <Bell className="w-5 h-5 sm:w-6 sm:h-6 group-hover:rotate-12 transition-transform" />
                    {hasUnreadAlerts && (
                      <>
                        <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-600 rounded-full border border-black animate-ping" />
                        <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-600 rounded-full border border-black" />
                      </>
                    )}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      audioService.playClick();
                      onClose();
                    }}
                    title="رجوع إلى القائمة"
                    className="min-w-[44px] min-h-[44px] p-2 sm:p-2.5 rounded-xl bg-gradient-to-br from-amber-500/20 via-red-950/60 to-slate-900 border-2 border-yellow-400/80 text-yellow-200 hover:text-white hover:border-yellow-300 shadow-[0_0_14px_rgba(250,204,21,0.45)] active:scale-95 transition-all cursor-pointer flex items-center justify-center"
                  >
                    <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6" />
                  </button>
                )}
              </div>

              {/* APP NAME, PHONE & INFO + 20% ENLARGED LANGUAGE TOGGLE ON RIGHT */}
              <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0">
                {/* 50% Scaled Golden Box */}
                <div className="px-2 sm:px-2.5 py-1 rounded-xl bg-black/80 border border-yellow-400/70 shadow-[0_0_12px_rgba(241,184,22,0.4)] text-right min-w-0 max-w-[44vw] sm:max-w-none">
                  <div className="text-[10.5px] sm:text-[11px] font-black text-yellow-300 tracking-wide leading-tight truncate">
                    {settings.appName} | {settings.phoneNumber}
                  </div>
                  <div className="text-[8.5px] sm:text-[9px] text-gray-300 font-mono mt-0.5 flex items-center justify-end gap-1 sm:gap-1.5 whitespace-nowrap">
                    <span className="text-cyan-400 font-bold">V19.2 HD 3D</span>
                    <span>•</span>
                    <span className="text-yellow-400">قصاصة {settings.concoursNumber}</span>
                  </div>
                </div>

                {/* Language Toggle AR / FR (تكبير بنسبة 20%) */}
                <button
                  onClick={() => {
                    audioService.playClick();
                    setLang(lang === 'FR' ? 'AR' : 'FR');
                  }}
                  title="تعريب / تغيير اللغة"
                  className="shrink-0 px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-xl bg-[#f1b816] text-black font-black text-sm sm:text-base leading-none hover:bg-yellow-300 border-2 border-yellow-200 shadow-[0_0_14px_rgba(241,184,22,0.75)] active:scale-95 transition-all cursor-pointer"
                >
                  {lang}
                </button>
              </div>
            </div>

        {/* 4. MAIN BODY CONTAINER (Full height behind transparent floating bottom glass bar) */}
        {activeBottomNav === 'grille' && grilleSubTab === 'mondiale' ? (
          /* GRILLE VIEW (خانة القصاصة): انسياب عمودي عادي تحت الشريط العلوي الشفاف والشريط السفلي الزجاجي */
          <div className="flex-1 relative overflow-hidden flex flex-col">
            {slipNoticeMessage && (
              <div className="absolute bottom-24 inset-x-3 z-40 p-2 rounded-xl bg-emerald-950/95 border border-emerald-400 text-emerald-200 font-bold text-xs flex items-center justify-between shadow-[0_0_15px_rgba(16,185,129,0.5)] animate-fade-in">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{slipNoticeMessage}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setSlipNoticeMessage(null)}
                  className="text-gray-400 hover:text-white p-0.5 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            <Grille3DWheelView
              matches={liveConcours.matches}
              lang={lang}
              isBettingLocked={isBettingLocked}
              selections={currentSelections}
              onToggleSelection={toggleSelection}
              getTeamName={getTeamName}
              goalFlashMatchIds={goalFlashMatchIds}
              onScrollHideTopBar={() => setIsGrilleRibbonOpen(false)}
              topOverlayContent={
                <PromosportUnifiedBadge
                  concours={liveConcours}
                  cagnotte={liveConcours.cagnotteEstimate}
                  lang={lang}
                  isKickoffStarted={isBettingLocked}
                  activeSubTab={grilleSubTab}
                  isOpen={isGrilleRibbonOpen}
                  onToggleOpen={setIsGrilleRibbonOpen}
                  onSelectSubTab={(tab) => {
                    audioService.playClick();
                    if (tab === 'slips') {
                      setGrilleSubTab('slips');
                    } else if (tab === 'mondiale') {
                      setActiveConcours(concours || INITIAL_WEEKLY_CONCOURS);
                      setGrilleSubTab('mondiale');
                    } else if (tab === 'nationale') {
                      setGrilleSubTab('nationale');
                    }
                  }}
                  slipsCount={userSlips.length}
                  showTabs={true}
                  transparentFloating={true}
                  showBettingControls={true}
                  totalSelections={totalSelections}
                  countDoubles={countDoubles}
                  countTriples={countTriples}
                  combinationsCount={pricing.combinations}
                  formattedPriceTnd={pricing.formattedTnd}
                  onSaveSlip={handleSaveSlip}
                  onClearSelections={handleClearSelections}
                />
              }
            />
          </div>
        ) : (
        <div className="flex-1 overflow-y-auto overflow-x-hidden relative overscroll-contain [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          
          {/* 2. UNIFIED PROMOSPORT CAGNOTTE & GRILLE BADGE */}
          {activeBottomNav !== 'apk' && activeBottomNav !== 'live' && (
            <div className="relative z-20 w-full bg-transparent">
              <PromosportUnifiedBadge
                concours={liveConcours}
                cagnotte={liveConcours.cagnotteEstimate}
                tirageGrille={activeBottomNav === 'tirage' ? activeTirage : null}
                onRefreshTirage={
                  activeBottomNav === 'tirage' && !isTirageOfficialFrozen
                    ? handleRefreshTirageFromSite
                    : undefined
                }
                isRefreshingTirage={isRefreshingTirage}
                lang={lang}
                isKickoffStarted={isBettingLocked}
                activeSubTab={grilleSubTab}
                onSelectSubTab={(tab) => {
                  audioService.playClick();
                  if (tab === 'slips') {
                    setActiveBottomNav('grille');
                    setGrilleSubTab('slips');
                  } else if (tab === 'mondiale') {
                    setActiveConcours(concours || INITIAL_WEEKLY_CONCOURS);
                    setGrilleSubTab('mondiale');
                  } else if (tab === 'nationale') {
                    setGrilleSubTab('nationale');
                  }
                }}
                slipsCount={userSlips.length}
                showTabs={activeBottomNav === 'grille'}
              />
            </div>
          )}

          <div className={`${activeBottomNav === 'grille' ? 'px-0 py-2' : 'p-2 sm:p-4'} pb-[92px] space-y-2.5`}>

          {/* ========================================================= */}
          {/* TAB 2: GRILLE (القصاصة) - Interactive Betting or Saved Slips */}
          {/* ========================================================= */}
          {activeBottomNav === 'grille' && (
            <>
              {grilleSubTab === 'nationale' ? (
                renderNationalUnavailableView()
              ) : grilleSubTab === 'slips' ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between px-3 sm:px-4">
                    <h3 className="text-sm font-black text-yellow-400 flex items-center gap-2">
                      <FolderArchive className="w-4 h-4" />
                      <span>سجل القصاصات المسجلة ({userSlips.length})</span>
                    </h3>
                    {userSlips.length > 0 && (
                      <button
                        type="button"
                        onClick={handleClearAllSlips}
                        className="px-2.5 py-1 rounded-xl bg-red-950/70 hover:bg-red-800 border border-red-500/60 text-red-300 hover:text-white text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer active:scale-95 shadow"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>فسخ جميع القصاصات</span>
                      </button>
                    )}
                  </div>

                  {slipNoticeMessage && (
                    <div className="p-2.5 rounded-xl bg-emerald-950/90 border border-emerald-500 text-emerald-200 font-bold text-xs flex items-center justify-between shadow-[0_0_15px_rgba(16,185,129,0.5)] animate-fade-in">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>{slipNoticeMessage}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setSlipNoticeMessage(null)}
                        className="text-gray-400 hover:text-white p-0.5 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  {userSlips.length === 0 ? (
                    <div className="p-8 rounded-2xl bg-[#071328] border border-white/10 text-center space-y-3">
                      <div className="w-12 h-12 rounded-full bg-white/5 border border-white/20 mx-auto flex items-center justify-center text-gray-400">
                        <FolderArchive className="w-6 h-6" />
                      </div>
                      <p className="text-sm text-gray-300 font-bold">
                        لا توجد قصاصات مسجلة حالياً
                      </p>
                      <p className="text-xs text-gray-400">
                        قم بتعمير القصاصة العالمية أو الوطنية واضغط "تسجيل القصاصة" لحفظها هنا بالترتيب.
                      </p>
                      <button
                        onClick={() => setGrilleSubTab('mondiale')}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-yellow-400 to-amber-500 text-black font-black text-xs shadow-md"
                      >
                        تعمير قصاصة جديدة
                      </button>
                    </div>
                  ) : (
                    userSlips.map((slip, slipIndex) => {
                      const isExpanded = expandedSlipId === slip.id;

                      return (
                        <div
                          key={slip.id}
                          className="rounded-2xl bg-[#08152e] border-2 border-yellow-500/60 overflow-hidden shadow-lg"
                        >
                          {/* Slip Header - Clicking opens full page 13-match view */}
                          <div
                            onClick={() => {
                              audioService.playClick();
                              setSelectedFullSlip(slip);
                            }}
                            className="p-3 bg-gradient-to-r from-[#091a38] via-[#0c2450] to-[#091a38] flex items-center justify-between cursor-pointer hover:bg-sky-950/60 transition-colors group"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div className="w-7 h-7 rounded-xl bg-yellow-400 text-black font-black text-xs flex items-center justify-center shadow shrink-0">
                                #{slipIndex + 1}
                              </div>
                              <div className="min-w-0">
                                <div className="flex flex-wrap items-center gap-1.5">
                                  <h4 className="font-black text-xs sm:text-sm text-yellow-300">
                                    {slip.name}
                                  </h4>
                                  <span className="px-2 py-0.5 rounded-md bg-cyan-500/20 border border-cyan-400/80 text-cyan-200 font-mono font-black text-[10px] sm:text-[11px] whitespace-nowrap">
                                    {lang === 'AR'
                                      ? `المسابقة #${slip.grilleNumber || liveConcours.number}`
                                      : `Concours N° ${slip.grilleNumber || liveConcours.number}`}
                                  </span>
                                </div>
                                <div className="text-[10px] text-gray-400 flex items-center gap-2 mt-0.5 flex-wrap">
                                  <span>بتاريخ: {slip.createdAt}</span>
                                  <span>•</span>
                                  <span className="text-cyan-400 font-mono">
                                    {slip.totalCombinations} عمود
                                  </span>
                                  <span>•</span>
                                  <span className="text-emerald-400 font-bold" dir="ltr">
                                    {slip.totalCostDt.toFixed(3)} TND
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              {!isBettingLocked && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleEditSlip(slip);
                                  }}
                                  title="تعديل القصاصة (متاح قبل بداية المباريات)"
                                  className="p-1.5 rounded-lg bg-sky-500/20 text-sky-300 hover:bg-sky-500 hover:text-black transition-colors"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>
                              )}

                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteSlip(slip.id);
                                }}
                                title="فسخ القصاصة نهائياً (متاح في أي وقت)"
                                className="px-2.5 py-1 rounded-xl bg-red-600/30 hover:bg-red-600 border border-red-500/60 text-red-200 hover:text-white transition-all flex items-center gap-1.5 text-xs font-bold shadow-md cursor-pointer active:scale-95"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>فسخ القصاصة</span>
                              </button>
                            </div>
                          </div>

                          {/* Expanded 13 Matches View with ✓ / ✗ */}
                          {isExpanded && (
                            <div className="px-0 py-2 bg-black/60 border-t border-white/10 space-y-1.5">
                              <div className="text-[11px] text-gray-300 font-bold px-3 pb-1 flex justify-between">
                                <span>المقابلات الـ 13 مع علامات الصح والخطأ والنتائج الرسمية:</span>
                                <span className="text-yellow-400">قصاصة مسابقة {slip.grilleNumber}</span>
                              </div>

                              {resolveConcoursForSlip(slip).matches.map((m) => {
                                const userChoices = slip.selections[m.id] || [];
                                return (
                                  <BroadcastScoreboardMatch
                                    key={m.id}
                                    match={m}
                                    lang={lang}
                                    mode="slip"
                                    isKickoffStarted={isBettingLocked}
                                    slipChoices={userChoices}
                                    getTeamName={getTeamName}
                                    justScoredGoal={Boolean(goalFlashMatchIds[m.id])}
                                  />
                                );
                              })}

                              {/* Footer Action: Delete Slip at any time */}
                              <div className="pt-2 flex items-center justify-between border-t border-white/10 px-3">
                                <span className="text-[10px] text-gray-400">
                                  يمكن فسخ أي قصاصة مسجلة في أي وقت
                                </span>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteSlip(slip.id);
                                  }}
                                  className="px-3 py-1 rounded-xl bg-red-600/40 hover:bg-red-600 border border-red-500 text-red-200 hover:text-white transition-all flex items-center gap-1.5 text-xs font-bold shadow cursor-pointer active:scale-95"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>فسخ هذه القصاصة نهائياً</span>
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              ) : null}
            </>
          )}

          {/* ========================================================= */}
          {/* TAB 3: TIRAGE (صورة جامدة فقط بدون بث مباشر — تحديث القيمة المالية والمرابيح فقط عند عدم ظهورها) */}
          {/* ========================================================= */}
          {activeBottomNav === 'tirage' && activeTirage && (
            <TirageFrozenSnapshotCard
              grille={activeTirage}
              lang={lang}
              getTeamName={getTeamName}
              isRefreshingPayouts={isRefreshingTirage}
              onRefreshPayoutsOnly={
                !isTirageOfficialFrozen ? handleRefreshTirageFromSite : undefined
              }
            />
          )}

          {activeBottomNav === 'tirage' && !activeTirage && (
            <div className="rounded-2xl bg-[#08152e]/90 border-2 border-yellow-400/60 p-6 text-center space-y-3">
              <p className="text-sm font-black text-yellow-300">
                جاري مزامنة القصاصة السابقة الأخيرة من الموقع...
              </p>
              <button
                type="button"
                onClick={handleRefreshTirageFromSite}
                disabled={isRefreshingTirage}
                className="min-h-[44px] px-4 py-2 rounded-xl inline-flex items-center gap-2 text-xs font-black bg-yellow-400 text-black hover:bg-yellow-300 cursor-pointer disabled:opacity-60"
              >
                <RefreshCw className={`w-4 h-4 ${isRefreshingTirage ? 'animate-spin' : ''}`} />
                <span>تحديث القصاصة السابقة الآن</span>
              </button>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 3: LIVE (المباشر - مسح نطاق الموقع والمقابلات الحية)    */}
          {/* ========================================================= */}
          {activeBottomNav === 'live' && (
            <LiveMatchesScanView
              lang={lang}
              getTeamName={getTeamName}
              onLiveCountChange={setLiveBadgeCount}
            />
          )}

          {/* ========================================================= */}
          {/* TAB 3: PROMPT / APK HUB + NEW UNLOCKED SETTINGS SUB-PAGE  */}
          {/* ========================================================= */}
          {activeBottomNav === 'apk' && (
            <div className="space-y-3">
              {/* Sub-Page Switcher inside Prompt Tab: Hub (PIN 1777) vs Settings (Unlocked without PIN) */}
              <div className="grid grid-cols-2 gap-2 p-1.5 rounded-2xl bg-[#071328] border border-sky-400/40 shadow-md">
                <button
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    setPromptSubPage('hub');
                  }}
                  className={`min-h-[44px] px-3 py-2 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95 ${
                    promptSubPage === 'hub'
                      ? 'bg-gradient-to-r from-cyan-400 to-sky-500 text-black shadow-[0_0_14px_rgba(34,211,238,0.5)]'
                      : 'text-gray-300 hover:text-white bg-black/30'
                  }`}
                >
                  <Smartphone className="w-4 h-4 shrink-0" />
                  <span>التثبيت وحزمة ZIP</span>
                  {!isProtectedTabsUnlocked && (
                    <Lock className={`w-3.5 h-3.5 shrink-0 ${promptSubPage === 'hub' ? 'text-black' : 'text-yellow-400'}`} />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    setPromptSubPage('settings');
                  }}
                  className={`min-h-[44px] px-3 py-2 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-95 ${
                    promptSubPage === 'settings'
                      ? 'bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 text-black shadow-[0_0_16px_rgba(250,204,21,0.55)]'
                      : 'text-yellow-300/90 hover:text-yellow-200 bg-black/30'
                  }`}
                >
                  <Settings className="w-4 h-4 shrink-0" />
                  <span>صفحة الإعدادات (مفتوحة)</span>
                </button>
              </div>

              {promptSubPage === 'settings' ? (
                /* UNLOCKED SETTINGS SUB-PAGE (opens freely without PIN) */
                <div className="space-y-3">
                  <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#0a1b38] via-[#0f2854] to-[#0a1b38] border border-yellow-500/50 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-9 h-9 rounded-xl bg-yellow-400 text-black flex items-center justify-center shrink-0">
                        <Settings className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-black text-sm text-yellow-300">
                          إعدادات التطبيق والقصاصات (مفتوحة بدون رقم سري)
                        </h3>
                        <p className="text-[11px] text-gray-300">
                          تعديل هوية التطبيق، معرف الحزمة، رقم الهاتف وضوابط القصاصات
                        </p>
                      </div>
                    </div>

                    {settingsSavedAlert && (
                      <span className="px-3 py-1 rounded-full bg-emerald-500 text-black font-black text-xs animate-bounce">
                        تم الحفظ بنجاح!
                      </span>
                    )}
                  </div>

                  <div className="space-y-2.5">
                    {/* 1. اسم التطبيق */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Smartphone className="w-4 h-4 text-cyan-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">اسم التطبيق</label>
                          <span className="text-[10px] text-gray-400 block truncate">الاسم الظاهر في الواجهة وشريط المهام</span>
                        </div>
                      </div>
                      <input
                        type="text"
                        value={settings.appName}
                        onChange={(e) => setSettings({ ...settings, appName: e.target.value })}
                        className="w-32 min-[380px]:w-44 sm:w-60 shrink-0 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs text-white text-right focus:border-yellow-400 outline-none"
                      />
                    </div>

                    {/* 2. معرف الحزمة */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Package className="w-4 h-4 text-yellow-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">معرف الحزمة (Package ID)</label>
                          <span className="text-[10px] text-gray-400 block truncate">معرف أندرويد لتطبيق الـ APK</span>
                        </div>
                      </div>
                      <input
                        type="text"
                        value={settings.packageId}
                        onChange={(e) => setSettings({ ...settings, packageId: e.target.value })}
                        className="w-32 min-[380px]:w-44 sm:w-60 shrink-0 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono text-cyan-300 text-left focus:border-yellow-400 outline-none"
                        dir="ltr"
                      />
                    </div>

                    {/* 3. رقم الهاتف */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <PhoneCall className="w-4 h-4 text-emerald-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">رقم الهاتف</label>
                          <span className="text-[10px] text-gray-400 block truncate">الرقم المذهب الظاهر في أعلى الواجهة</span>
                        </div>
                      </div>
                      <input
                        type="text"
                        value={settings.phoneNumber}
                        onChange={(e) => setSettings({ ...settings, phoneNumber: e.target.value })}
                        className="w-32 min-[380px]:w-44 sm:w-60 shrink-0 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono font-bold text-emerald-400 text-center focus:border-yellow-400 outline-none"
                        dir="ltr"
                      />
                    </div>

                    {/* 4. رقم القصاصة */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Hash className="w-4 h-4 text-amber-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">رقم القصاصة</label>
                          <span className="text-[10px] text-gray-400 block truncate">ترقيم المسابقة الحالية (مثل {liveConcours.number})</span>
                        </div>
                      </div>
                      <input
                        type="number"
                        value={settings.concoursNumber}
                        onChange={(e) => setSettings({ ...settings, concoursNumber: Number(e.target.value) })}
                        className="w-24 sm:w-32 shrink-0 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono font-bold text-yellow-300 text-center focus:border-yellow-400 outline-none"
                      />
                    </div>

                    {/* 5. تسعيرة العمود */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Coins className="w-4 h-4 text-yellow-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">تسعيرة العمود (د.ت)</label>
                          <span className="text-[10px] text-gray-400 block truncate">المعادلة الرسمية: 0.150 دينار للعمود</span>
                        </div>
                      </div>
                      <input
                        type="number"
                        step="0.010"
                        value={settings.columnRate}
                        onChange={(e) => setSettings({ ...settings, columnRate: parseFloat(e.target.value) || 0.150 })}
                        className="w-24 sm:w-32 shrink-0 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono font-bold text-cyan-300 text-center focus:border-yellow-400 outline-none"
                      />
                    </div>

                    {/* 6. معلوم القصاصة */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <Receipt className="w-4 h-4 text-pink-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">معلوم القصاصة (الطابع الجبائي د.ت)</label>
                          <span className="text-[10px] text-gray-400 block truncate">المعلوم الثابت: 0.250 دينار لكل قصاصة</span>
                        </div>
                      </div>
                      <input
                        type="number"
                        step="0.010"
                        value={settings.baseFee}
                        onChange={(e) => setSettings({ ...settings, baseFee: parseFloat(e.target.value) || 0.250 })}
                        className="w-24 sm:w-32 shrink-0 px-3 py-1.5 rounded-xl bg-black/70 border border-white/20 text-xs font-mono font-bold text-pink-300 text-center focus:border-yellow-400 outline-none"
                      />
                    </div>

                    {/* 7. تفعيل سجل القصاصات */}
                    <div className="p-3 rounded-2xl bg-[#08152e] border border-white/10 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                        <div className="min-w-0">
                          <label className="text-xs font-bold text-gray-300 block">تفعيل سجل القصاصات</label>
                          <span className="text-[10px] text-gray-400 block truncate">إظهار تبويب القصاصات المسجلة واسترجاعها</span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          audioService.playClick();
                          setSettings({ ...settings, enableSlipsHistory: !settings.enableSlipsHistory });
                        }}
                        className={`shrink-0 px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                          settings.enableSlipsHistory
                            ? 'bg-emerald-500 text-black shadow-[0_0_10px_rgba(16,185,129,0.7)]'
                            : 'bg-white/10 text-gray-400'
                        }`}
                      >
                        {settings.enableSlipsHistory ? 'مفعل ✓' : 'معطل ✗'}
                      </button>
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={handleSaveAppSettings}
                      className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 text-black font-black text-xs shadow-[0_0_15px_rgba(241,184,22,0.7)] hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>حفظ وتطبيق الإعدادات</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleResetAppSettings}
                      className="py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-gray-300 text-xs font-bold transition-all cursor-pointer"
                    >
                      استعادة الافتراضي
                    </button>
                  </div>
                </div>
              ) : !isProtectedTabsUnlocked ? (
                /* PIN 1777 GATE FOR APK/ZIP PROMPT HUB */
                <div className="py-4 sm:py-6 px-2 flex flex-col items-center justify-center min-h-[48dvh]">
                  <form
                    onSubmit={handlePinSubmit}
                    className="w-full max-w-sm rounded-3xl bg-[#08152e] border-2 border-yellow-400/80 p-5 sm:p-6 shadow-[0_0_40px_rgba(241,184,22,0.3)] space-y-4 text-center"
                  >
                    <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-yellow-300 via-amber-400 to-yellow-600 text-black flex items-center justify-center shadow-[0_0_20px_rgba(241,184,22,0.75)] border-2 border-yellow-100">
                      <Lock className="w-7 h-7" />
                    </div>

                    <div className="space-y-1">
                      <h3 className="font-black text-base text-yellow-300">
                        خانة برومبت APK محمية بكلمة سر
                      </h3>
                      <p className="text-[11px] text-gray-300 leading-relaxed">
                        أدخل كلمة السر لفتح مركز التثبيت وحزمة ZIP، أو افتح الإعدادات مباشرة بدون رقم سري أعلاه
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="relative">
                        <KeyRound className="w-4 h-4 text-yellow-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                        <input
                          type="password"
                          inputMode="numeric"
                          maxLength={6}
                          value={pinInput}
                          onChange={(e) => handlePinChange(e.target.value)}
                          placeholder="••••"
                          dir="ltr"
                          className="w-full py-2.5 px-10 rounded-xl bg-black/80 border-2 border-sky-400/60 focus:border-yellow-400 text-center font-mono text-xl font-black tracking-[0.45em] text-yellow-300 outline-none shadow-inner"
                        />
                      </div>

                      {pinError && (
                        <div className="text-xs font-bold text-red-300 bg-red-950/60 border border-red-500/60 rounded-xl py-1.5 px-3">
                          {pinError}
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-1" dir="ltr">
                      {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                        <button
                          key={digit}
                          type="button"
                          onClick={() => {
                            audioService.playClick();
                            handlePinChange(pinInput + digit);
                          }}
                          className="min-h-[44px] rounded-xl bg-[#0b1f42] hover:bg-[#123166] active:scale-95 border border-sky-400/40 hover:border-yellow-400 text-white font-mono font-black text-lg transition-all cursor-pointer shadow"
                        >
                          {digit}
                        </button>
                      ))}
                      <button
                        type="button"
                        onClick={() => {
                          audioService.playClick();
                          setPinInput('');
                          setPinError(null);
                        }}
                        className="min-h-[44px] rounded-xl bg-red-950/60 hover:bg-red-900/80 active:scale-95 border border-red-500/40 text-red-200 font-bold text-xs transition-all cursor-pointer"
                      >
                        مسح
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          audioService.playClick();
                          handlePinChange(pinInput + '0');
                        }}
                        className="min-h-[44px] rounded-xl bg-[#0b1f42] hover:bg-[#123166] active:scale-95 border border-sky-400/40 hover:border-yellow-400 text-white font-mono font-black text-lg transition-all cursor-pointer shadow"
                      >
                        0
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          audioService.playClick();
                          setPinInput((prev) => prev.slice(0, -1));
                          setPinError(null);
                        }}
                        title="حذف رقم"
                        className="min-h-[44px] rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 border border-white/20 text-gray-200 flex items-center justify-center transition-all cursor-pointer"
                      >
                        <Delete className="w-5 h-5" />
                      </button>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 rounded-xl bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 text-black font-black text-sm shadow-[0_0_18px_rgba(241,184,22,0.75)] hover:brightness-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Unlock className="w-4 h-4" />
                      <span>فتح الخانة</span>
                    </button>
                  </form>
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={() => {
                        audioService.playClick();
                        setIsProtectedTabsUnlocked(false);
                        setPinInput('');
                      }}
                      className="px-3 py-1 rounded-xl bg-[#08152e] hover:bg-[#0f254d] border border-yellow-400/50 text-yellow-300 text-[11px] font-bold flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>قفل خانة برومبت</span>
                    </button>
                  </div>
                  <AppInstallPromptHub
                    settings={settings}
                    userSlips={userSlips}
                    concours={liveConcours}
                  />
                </div>
              )}
            </div>
          )}

          </div>
        </div>
        )}

        {/* 6. BOTTOM TRANSPARENT GLASS 4-TABS NAVIGATION BAR (القصاصة | Tirage | المباشر | برومبت APK) */}
        <div className="absolute bottom-0 inset-x-0 px-1.5 sm:px-2 pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] bg-white/[0.06] backdrop-blur-md border-t border-sky-400/50 shadow-[0_-8px_28px_rgba(0,0,0,0.45)] grid grid-cols-4 gap-1.5 select-none z-30">

          {/* 1. القصاصة */}
          <button
            type="button"
            data-no-flash="true"
            onClick={() => {
              audioService.playClick();
              setActiveBottomNav('grille');
              onTabChange?.('grille');
            }}
            className={`min-h-[54px] flex flex-col items-center justify-center py-1 px-1 rounded-xl border-2 transition-all cursor-pointer ${
              activeBottomNav === 'grille'
                ? 'bg-sky-500/25 border-sky-300 text-yellow-300 font-black shadow-[0_0_16px_rgba(56,189,248,0.65)]'
                : 'bg-black/30 hover:bg-sky-500/15 border-sky-400/85 text-sky-100 hover:text-white shadow-[0_0_10px_rgba(56,189,248,0.28)]'
            }`}
          >
            <div
              className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center mb-0.5 transition-all ${
                activeBottomNav === 'grille'
                  ? 'border-sky-300 bg-[#f1b816] text-black shadow-[0_0_10px_rgba(241,184,22,0.85)]'
                  : 'border-sky-400 bg-sky-500/15 text-sky-200'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </div>
            <span className="text-[10px] sm:text-[10.5px] font-black drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] whitespace-nowrap">
              القصاصة
            </span>
          </button>

          {/* 2. Tirage */}
          <button
            type="button"
            data-no-flash="true"
            onClick={() => {
              audioService.playClick();
              setActiveBottomNav('tirage');
              onTabChange?.('tirage');
            }}
            className={`min-h-[54px] flex flex-col items-center justify-center py-1 px-1 rounded-xl border-2 transition-all cursor-pointer ${
              activeBottomNav === 'tirage'
                ? 'bg-sky-500/25 border-sky-300 text-cyan-200 font-black shadow-[0_0_16px_rgba(56,189,248,0.65)]'
                : 'bg-black/30 hover:bg-sky-500/15 border-sky-400/85 text-sky-100 hover:text-white shadow-[0_0_10px_rgba(56,189,248,0.28)]'
            }`}
          >
            <div
              className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center mb-0.5 transition-all ${
                activeBottomNav === 'tirage'
                  ? 'border-sky-300 bg-cyan-400 text-black shadow-[0_0_10px_rgba(34,211,238,0.85)]'
                  : 'border-sky-400 bg-sky-500/15 text-sky-200'
              }`}
            >
              <Ticket className="w-4 h-4" />
            </div>
            <span className="text-[10px] sm:text-[10.5px] font-black drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] whitespace-nowrap">
              Tirage
            </span>
          </button>

          {/* 3. المباشر (بجانب Tirage مباشرة - مسح نطاق الموقع والمقابلات المباشرة لحظة بلحظة) */}
          <button
            type="button"
            data-no-flash="true"
            onClick={() => {
              audioService.playClick();
              setActiveBottomNav('live');
              onTabChange?.('live');
            }}
            className={`relative min-h-[54px] flex flex-col items-center justify-center py-1 px-1 rounded-xl border-2 transition-all cursor-pointer ${
              activeBottomNav === 'live'
                ? 'bg-emerald-500/25 border-sky-300 text-emerald-200 font-black shadow-[0_0_18px_rgba(16,185,129,0.75)]'
                : 'bg-black/30 hover:bg-sky-500/15 border-sky-400/85 text-sky-100 hover:text-white shadow-[0_0_10px_rgba(56,189,248,0.28)]'
            }`}
          >
            {liveBadgeCount > 0 && (
              <span className="absolute top-1 left-1.5 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-85" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400 border border-black" />
              </span>
            )}
            <div
              className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center mb-0.5 transition-all ${
                activeBottomNav === 'live'
                  ? 'border-sky-300 bg-emerald-400 text-black shadow-[0_0_10px_rgba(16,185,129,0.9)]'
                  : 'border-sky-400 bg-sky-500/15 text-emerald-300'
              }`}
            >
              <Radio className="w-4 h-4" />
            </div>
            <span className="text-[10px] sm:text-[10.5px] font-black drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] whitespace-nowrap">
              المباشر
            </span>
          </button>

          {/* 4. برومبت APK (يحتوي على التثبيت + صفحة الإعدادات الجديدة بدون رقم سري) */}
          <button
            type="button"
            data-no-flash="true"
            onClick={() => {
              audioService.playClick();
              setPinError(null);
              setActiveBottomNav('apk');
              onTabChange?.('apk');
            }}
            className={`min-h-[54px] flex flex-col items-center justify-center py-1 px-1 rounded-xl border-2 transition-all cursor-pointer ${
              activeBottomNav === 'apk'
                ? 'bg-sky-500/25 border-sky-300 text-cyan-200 font-black shadow-[0_0_16px_rgba(56,189,248,0.65)]'
                : 'bg-black/30 hover:bg-sky-500/15 border-sky-400/85 text-sky-100 hover:text-white shadow-[0_0_10px_rgba(56,189,248,0.28)]'
            }`}
          >
            <div
              className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center mb-0.5 transition-all ${
                activeBottomNav === 'apk'
                  ? 'border-sky-300 bg-cyan-400 text-black shadow-[0_0_10px_rgba(34,211,238,0.85)]'
                  : 'border-sky-400 bg-sky-500/15 text-sky-200'
              }`}
            >
              <Smartphone className="w-4 h-4" />
            </div>
            <span className="text-[10px] sm:text-[10.5px] font-black drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)] whitespace-nowrap">
              برومبت APK
            </span>
          </button>

        </div>
          </>
        )}

      </div>
    </div>
  );
};
