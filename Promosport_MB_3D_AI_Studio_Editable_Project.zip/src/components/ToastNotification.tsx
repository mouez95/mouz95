/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { Bell, Trophy, Sparkles, X, CheckCircle, AlertCircle } from 'lucide-react';
import { ToastAlert } from '../types/promosport';

interface ToastNotificationProps {
  alert: ToastAlert | null;
  onDismiss: () => void;
  durationSeconds: number; // 5, 10, 15, or 0 (until dismissed)
}

export const ToastNotification: React.FC<ToastNotificationProps> = ({
  alert,
  onDismiss,
  durationSeconds,
}) => {
  useEffect(() => {
    if (!alert) return;
    if (durationSeconds > 0) {
      const timer = setTimeout(() => {
        onDismiss();
      }, durationSeconds * 1000);
      return () => clearTimeout(timer);
    }
  }, [alert, durationSeconds, onDismiss]);

  if (!alert) return null;

  const getIcon = () => {
    switch (alert.type) {
      case 'result':
        return <Trophy className="w-5 h-5 text-yellow-400" />;
      case 'cagnotte':
        return <Sparkles className="w-5 h-5 text-amber-400" />;
      case 'golden':
        return <CheckCircle className="w-5 h-5 text-yellow-300" />;
      default:
        return <Bell className="w-5 h-5 text-red-400" />;
    }
  };

  return (
    <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[75] w-[92vw] max-w-lg pointer-events-auto animate-fadeIn">
      <div className="relative p-4 rounded-2xl bg-black/90 border border-yellow-500/70 shadow-[0_0_30px_rgba(234,179,8,0.4)] flex items-start justify-between gap-3 text-white">
        {/* Glow ambient */}
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-red-600/10 via-yellow-500/10 to-red-600/10 pointer-events-none" />

        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-stone-900 border border-yellow-500/30">
            {getIcon()}
          </div>
          <div>
            <div className="text-xs font-black text-yellow-400 flex items-center gap-2">
              <span>{alert.title}</span>
              <span className="text-[10px] text-gray-400 font-normal font-mono" dir="ltr">
                {alert.timestamp}
              </span>
            </div>
            <div className="text-xs text-gray-200 mt-1 leading-relaxed">{alert.message}</div>
            {durationSeconds > 0 && (
              <div className="text-[10px] text-yellow-500/70 mt-1.5 flex items-center gap-1">
                <span>يختفي التنبيه تلقائياً بعد {durationSeconds} ثوانٍ</span>
              </div>
            )}
          </div>
        </div>

        <button
          onClick={onDismiss}
          className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-stone-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
